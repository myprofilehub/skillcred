# AROGYACARE HEALTH INSURANCE — POLICY WORDING
Individual Health Indemnity Policy | Document version 3.4 | UIN: FICTIONAL/HEALTH/2024/002

## SECTION 1 — DEFINITIONS

1.1 "Hospital" means an institution with at least 10 inpatient beds in towns with a population
below ten lakh and 15 inpatient beds elsewhere, with qualified nursing staff and medical
practitioners available 24 hours, a fully equipped operation theatre, and daily records maintained.

1.2 "Hospitalisation" means admission to a Hospital for a continuous period of not less than 24
consecutive hours, save for Day Care Treatment.

1.3 "Day Care Treatment" means medical treatment or surgical procedure undertaken under general or
local anaesthesia in a Hospital in less than 24 hours, listed at Annexure B.

1.4 "Pre-Existing Disease" means any condition, ailment, injury or disease that is diagnosed by a
physician within 48 months prior to the effective date of the Policy, or for which medical advice
or treatment was recommended by or received from a physician within 48 months prior.

1.5 "Waiting Period" means the period from the inception of the Policy during which specified
benefits are not payable.

1.6 "Sum Insured" means the maximum amount of cover available under the Policy in a Policy Year.

1.7 "Co-payment" means a cost sharing requirement under which the Insured bears a specified
percentage of the admissible claim amount.

1.8 "Room Rent" means the amount charged by a Hospital for occupancy of a bed, including
associated nursing and service charges.

## SECTION 2 — COVERAGE

2.1 In-patient Treatment
The Company shall indemnify Reasonable and Customary Charges for hospitalisation including room
rent, nursing, intensive care, surgeon and anaesthetist fees, operation theatre charges, diagnostic
procedures, drugs and consumables, and cost of prosthetic devices implanted during surgery.

2.2 Room Rent Limits
Room rent is capped at 1% of Sum Insured per day for a normal room and 2% for an ICU bed.
Where the Insured occupies a room exceeding the eligible category, all associated charges
including surgeon fees and investigation charges shall be payable in the same proportion that the
eligible room rent bears to the actual room rent.

2.3 Pre and Post Hospitalisation
Medical expenses incurred 30 days before and 60 days after hospitalisation are payable, provided
the hospitalisation claim itself is admissible.

2.4 Day Care Procedures
The procedures listed at Annexure B are covered without the 24-hour hospitalisation requirement.

2.5 Ambulance
Road ambulance charges up to INR 2,000 per hospitalisation.

2.6 Annual Health Check-up
Available after two continuous claim-free Policy Years, up to 1% of Sum Insured.

## SECTION 3 — WAITING PERIODS

3.1 Initial Waiting Period: 30 days from inception, except for accidental injury.

3.2 Specified Disease Waiting Period: 24 months for cataract, hernia, hydrocele, benign prostatic
hypertrophy, hysterectomy, fissure, fistula, haemorrhoids, sinusitis, gallstones, kidney stones,
varicose veins, and joint replacement other than following accident.

3.3 Pre-Existing Disease Waiting Period: 36 months of continuous coverage.

3.4 Maternity Waiting Period: 36 months. Maternity is covered only where the optional maternity
benefit has been selected and the premium paid.

## SECTION 4 — EXCLUSIONS

4.1 Any treatment within the applicable Waiting Period.
4.2 Cosmetic or plastic surgery, unless necessitated by accident, burns or cancer.
4.3 Dental treatment, unless necessitated by accidental injury requiring hospitalisation.
4.4 Spectacles, contact lenses, hearing aids.
4.5 Treatment for obesity or weight control, unless meeting the criteria at Annexure C.
4.6 Change of gender treatment.
4.7 Treatment for alcoholism, drug or substance abuse.
4.8 Self-inflicted injury and attempted suicide.
4.9 Treatment received outside India, unless the overseas extension has been selected.
4.10 Unproven treatments, experimental procedures, and treatment not supported by evidence.
4.11 Expenses for items of personal comfort and convenience, listed at Annexure D.
4.12 Hospitalisation primarily for diagnostic purposes where no positive existence of a condition
requiring treatment is established.

## SECTION 5 — CLAIMS

5.1 Cashless: intimate the Company at least 48 hours before planned hospitalisation, or within 24
hours of emergency admission. Pre-authorisation is issued to the network hospital.

5.2 Reimbursement: submit the claim form, discharge summary, all bills in original, investigation
reports, and prescriptions within 15 days of discharge.

5.3 The Company shall settle or repudiate within 30 days of receipt of the last necessary document.

5.4 Co-payment of 20% applies to all claims where the Insured is aged 61 years or above at the time
of first inception.

## SECTION 6 — GENERAL CONDITIONS
6.1 Free look period of 15 days from receipt of the Policy.
6.2 Grace period of 30 days for renewal. Continuity of Waiting Periods is preserved if renewed
within the grace period; cover does not subsist during the grace period itself.
6.3 Lifelong renewability, subject to the Policy not being obtained by fraud or misrepresentation.
6.4 Portability is available as per IRDAI guidelines with 45 days' advance notice.
6.5 Cumulative bonus of 10% of Sum Insured for each claim-free year, up to 50%, reduced by 10% for
each year in which a claim is made.
