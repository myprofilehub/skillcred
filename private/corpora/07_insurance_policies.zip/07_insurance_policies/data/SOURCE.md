# Source

Synthetic. Two fictional insurers, written for SkillCred assignment 07.
No real policy wording is reproduced. UINs are invented and are not valid IRDAI identifiers.
This is a teaching artefact and must not be relied upon for any insurance decision.
Free to redistribute.
