# SHIELDMAX MOTOR INSURANCE — POLICY WORDING
Two Wheeler Package Policy | Document version 6.1 | UIN: FICTIONAL/MOTOR/2024/001

## SECTION 1 — PREAMBLE
Whereas the Insured has made a proposal to ShieldMax General Insurance Company Limited
(hereinafter "the Company") and has paid the premium stated in the Schedule, the Company agrees,
subject to the terms, conditions, limitations and exclusions of this Policy, to indemnify the
Insured in the manner set out below.

## SECTION 2 — DEFINITIONS
For the purposes of this Policy, the following expressions bear the meanings assigned to them:

2.1 "Insured Vehicle" means the two wheeler described in the Schedule.

2.2 "Insured Declared Value" or "IDV" means the value fixed at the commencement of the Policy,
being the manufacturer's listed selling price less depreciation as per the schedule of depreciation
at Annexure A.

2.3 "Accident" means a sudden, unforeseen and involuntary event caused by external, visible and
violent means.

2.4 "Theft" means the dishonest taking of the Insured Vehicle with the intention of permanently
depriving the Insured of it, as contemplated by Section 378 of the Indian Penal Code.

2.5 **"Reasonable Care" means the standard of care that a prudent owner would exercise in respect
of their own property. Without limiting the generality of the foregoing, the Insured shall be
regarded as having failed to exercise Reasonable Care where the Insured Vehicle is left unattended
with the ignition key in the ignition, in the lock, or otherwise accessible on or about the vehicle,
whether or not the steering lock is engaged, and whether or not the period of absence is brief.**

2.6 "Unattended" means the absence of the Insured or an authorised person from the immediate
vicinity of the Insured Vehicle such that the vehicle is not under effective observation.

2.7 "Period of Insurance" means the period stated in the Schedule.

2.8 "Total Loss" means damage where the aggregate cost of retrieval and repair exceeds 75% of the IDV.

2.9 "Deductible" means the amount stated in the Schedule which the Insured bears on each claim.

## SECTION 3 — SCOPE OF COVER

3.1 Own Damage
The Company shall indemnify the Insured against loss of or damage to the Insured Vehicle caused by:
(a) fire, explosion, self-ignition or lightning;
(b) burglary, housebreaking or theft;
(c) riot and strike;
(d) earthquake (fire and shock damage);
(e) flood, typhoon, hurricane, storm, tempest, inundation, cyclone, hailstorm, frost;
(f) accidental external means;
(g) malicious act;
(h) terrorist activity;
(i) whilst in transit by road, rail, inland waterway, lift, elevator or air;
(j) landslide or rockslide.

3.2 Third Party Liability
The Company shall indemnify the Insured against liability at law for death of or bodily injury to
any person, and for damage to third party property up to INR 1,00,000.

3.3 Personal Accident Cover
Compulsory personal accident cover of INR 15,00,000 for the owner-driver.

## SECTION 4 — GENERAL EXCLUSIONS

The Company shall not be liable in respect of:

4.1 Consequential loss, depreciation, wear and tear, mechanical or electrical breakdown, failure
or breakage.

4.2 Damage to tyres and tubes unless the Insured Vehicle is damaged at the same time, in which case
liability is limited to 50% of the cost of replacement.

4.3 Any accidental loss or damage suffered whilst the Insured or any person driving with the
Insured's knowledge and consent is under the influence of intoxicating liquor or drugs.

4.4 Any claim arising whilst the Insured Vehicle is being used otherwise than in accordance with
the Limitations as to Use stated in the Schedule.

4.5 Any claim arising whilst the person driving holds no effective driving licence, or is
disqualified from holding one.

4.6 Loss of or damage to the Insured Vehicle arising out of any act of war, invasion, foreign
enemy hostilities, civil war, rebellion, or nuclear risk.

4.7 **Any claim for theft of the Insured Vehicle where the Insured has failed to exercise
Reasonable Care as defined in Clause 2.5 of this Policy.** The burden of demonstrating that
Reasonable Care was exercised rests with the Insured.

4.8 Any claim where the keys of the Insured Vehicle are not surrendered to the Company at the time
of settlement of a theft claim. Where only one key is surrendered and the Schedule records two,
the claim shall be repudiated unless the loss of the second key was reported to the police prior
to the date of theft.

4.9 Any claim in respect of a vehicle used for hire or reward where the Schedule records private use.

## SECTION 5 — CONDITIONS

5.1 Notice of any loss shall be given to the Company immediately and in any event within 48 hours.

5.2 In the event of theft, a First Information Report shall be lodged with the police immediately
and a copy furnished to the Company. Delay in lodging the FIR beyond 24 hours without satisfactory
explanation may prejudice the claim.

5.3 The Insured shall take all reasonable steps to safeguard the Insured Vehicle from loss or
damage and to maintain it in efficient condition.

5.4 The Company shall have the option of repairing, reinstating or replacing the Insured Vehicle,
or paying the amount of loss in cash, at its sole discretion.

5.5 No admission, offer, promise, payment or indemnity shall be made by the Insured without the
written consent of the Company.

5.6 The Company may cancel this Policy by seven days' notice, refunding premium on a pro-rata basis.
The Insured may cancel at any time, refund being on the Company's short period scale.

5.7 If any claim is fraudulent, or if any fraudulent means are used to obtain benefit under this
Policy, all benefits shall be forfeited.

5.8 Disputes as to quantum, liability being admitted, shall be referred to arbitration under the
Arbitration and Conciliation Act, 1996.

## SECTION 6 — CLAIMS PROCEDURE
6.1 Intimate the claim through the helpline, the mobile application, or the branch.
6.2 Furnish the claim form, policy copy, registration certificate, driving licence and FIR (theft).
6.3 A surveyor will be appointed within 48 hours for own damage claims exceeding INR 20,000.
6.4 The Company shall settle or repudiate the claim within 30 days of receipt of the final survey report.

## SECTION 7 — NO CLAIM BONUS
| Consecutive claim-free years | Discount on Own Damage premium |
|---|---|
| 1 | 20% |
| 2 | 25% |
| 3 | 35% |
| 4 | 45% |
| 5 or more | 50% |
No Claim Bonus is lost entirely on a single claim, other than a windscreen-only claim.

## ANNEXURE A — SCHEDULE OF DEPRECIATION FOR IDV
| Age of vehicle | Depreciation |
|---|---|
| Not exceeding 6 months | 5% |
| 6 months to 1 year | 15% |
| 1 to 2 years | 20% |
| 2 to 3 years | 30% |
| 3 to 4 years | 40% |
| 4 to 5 years | 50% |
