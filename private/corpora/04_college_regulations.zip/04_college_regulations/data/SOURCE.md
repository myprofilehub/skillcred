# Source

Synthetic. Fictional institution, fictional regulations and syllabi, written for SkillCred
assignment 04. No real university's regulations or course content is reproduced.
Free to redistribute.
