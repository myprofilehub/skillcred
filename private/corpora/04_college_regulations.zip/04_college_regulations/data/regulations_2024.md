# ACADEMIC REGULATIONS 2024 — VELLORE INSTITUTE OF APPLIED SCIENCES (Fictional)
## B.Tech Programme, Choice Based Credit System

## R1. Programme Structure
The B.Tech programme extends over eight semesters across four academic years. The total credit
requirement for the award of the degree is 160 credits.

## R2. Credit Distribution

| Category | Code | Credits Required |
|---|---|---|
| Basic Sciences | BS | 22 |
| Engineering Sciences | ES | 24 |
| Programme Core | PC | 62 |
| Programme Electives | PE | 18 |
| Open Electives | OE | 12 |
| Humanities and Management | HM | 10 |
| Project and Internship | PJ | 12 |
| **Total** | | **160** |

## R3. Registration Limits

| Semester | Minimum Credits | Normal Credits | Maximum Credits |
|---|---|---|---|
| I | 18 | 22 | 26 |
| II | 18 | 22 | 26 |
| III | 18 | 23 | 27 |
| IV | 18 | 23 | 27 |
| V | 16 | 21 | 25 |
| VI | 16 | 21 | 25 |
| VII | 12 | 18 | 22 |
| VIII | 8 | 14 | 18 |

## R4. Promotion to Higher Semesters

Promotion from one semester to the next within an academic year is automatic. Promotion across
academic years is governed by the credit thresholds set out in the table below. A student who does
not meet the threshold shall be detained and shall re-register for the deficient courses.

| Promotion | Semesters Completed | Minimum Credits To Be Earned |
|---|---|---|
| Year 1 to Year 2 (Sem II to Sem III) | 2 | 30 |
| Year 2 to Year 3 (Sem IV to Sem V) | 4 | 66 |
| Year 3 to Year 4 (Sem VI to Sem VII) | 6 | 104 |

For the avoidance of doubt, the figure of 66 credits in the second row above is the requirement for
entry into Semester V and is computed on the aggregate of Semesters I to IV inclusive.

## R5. Attendance
R5.1 A minimum of 75% attendance in each course is required to be eligible for the end-semester examination.
R5.2 Attendance between 65% and 75% may be condoned by the Dean on medical grounds with documentary evidence.
R5.3 Attendance below 65% results in course failure with grade N, regardless of internal marks.

## R6. Assessment and Grading
R6.1 Internal assessment carries 40 marks; the end-semester examination carries 60 marks.
R6.2 A minimum of 40% in the end-semester examination is required to pass, in addition to 50% aggregate.

| Grade | Marks Range | Grade Point |
|---|---|---|
| S | 90–100 | 10 |
| A | 80–89 | 9 |
| B | 70–79 | 8 |
| C | 60–69 | 7 |
| D | 55–59 | 6 |
| E | 50–54 | 5 |
| F | Below 50 | 0 |
| N | Attendance shortage | 0 |

## R7. Supplementary Examination
R7.1 A student with grade F may appear in the supplementary examination held before the next semester.
R7.2 Grade N cannot be cleared by supplementary examination; the course must be re-registered.
R7.3 A maximum of four supplementary attempts is permitted per course.

## R8. Award of Degree
R8.1 The degree is awarded on earning 160 credits with a CGPA of not less than 5.0.
R8.2 The maximum permissible duration for completion is seven years from the date of first admission.
R8.3 First Class with Distinction requires a CGPA of 8.5 or above with no course failure at first attempt.
