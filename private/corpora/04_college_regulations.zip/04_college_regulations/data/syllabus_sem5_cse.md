# SYLLABUS — B.Tech Computer Science and Engineering, Semester V

| Code | Course | Category | L | T | P | Credits |
|---|---|---|---|---|---|---|
| CS3501 | Machine Learning | PC | 3 | 0 | 0 | 3 |
| CS3502 | Compiler Design | PC | 3 | 0 | 0 | 3 |
| CS3503 | Software Engineering | PC | 3 | 0 | 0 | 3 |
| CS35XX | Programme Elective I | PE | 3 | 0 | 0 | 3 |
| CS35XX | Programme Elective II | PE | 3 | 0 | 0 | 3 |
| CS3551 | Machine Learning Laboratory | PC | 0 | 0 | 3 | 2 |
| CS3552 | Mini Project | PJ | 0 | 0 | 4 | 2 |
| OE35XX | Open Elective II | OE | 3 | 0 | 0 | 3 |
| **Total** | | | | | | **22** |

## Prerequisites
CS3501 Machine Learning requires MA2401 Probability and Statistics to have been cleared.
CS3502 Compiler Design requires CS2401 Design and Analysis of Algorithms to have been cleared.
A student carrying an arrear in either prerequisite may not register for the dependent course.

## CS3501 — Machine Learning
Unit I: Supervised learning, linear and logistic regression, regularisation.
Unit II: Decision trees, ensembles, bagging and boosting.
Unit III: Unsupervised learning, clustering, dimensionality reduction.
Unit IV: Neural networks, backpropagation, optimisation.
Unit V: Model evaluation, bias-variance, cross-validation, deployment considerations.

## CS3502 — Compiler Design
Unit I: Lexical analysis, finite automata, regular expressions.
Unit II: Parsing, LL and LR techniques, syntax-directed translation.
Unit III: Semantic analysis, symbol tables, type checking.
Unit IV: Intermediate code generation, optimisation.
Unit V: Code generation, register allocation, runtime environments.

## CS3503 — Software Engineering
Unit I: Process models, agile methods.
Unit II: Requirements engineering, specification.
Unit III: Design principles, architectural patterns.
Unit IV: Testing strategies, verification and validation.
Unit V: Project management, estimation, risk, maintenance.
