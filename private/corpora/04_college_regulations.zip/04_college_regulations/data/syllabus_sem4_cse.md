# SYLLABUS — B.Tech Computer Science and Engineering, Semester IV

| Code | Course | Category | L | T | P | Credits |
|---|---|---|---|---|---|---|
| MA2401 | Probability and Statistics | BS | 3 | 1 | 0 | 4 |
| CS2401 | Design and Analysis of Algorithms | PC | 3 | 0 | 0 | 3 |
| CS2402 | Operating Systems | PC | 3 | 0 | 0 | 3 |
| CS2403 | Computer Networks | PC | 3 | 0 | 0 | 3 |
| CS2404 | Database Management Systems | PC | 3 | 0 | 0 | 3 |
| CS2451 | Algorithms Laboratory | PC | 0 | 0 | 3 | 2 |
| CS2452 | Operating Systems Laboratory | PC | 0 | 0 | 3 | 2 |
| HM2401 | Professional Ethics | HM | 2 | 0 | 0 | 2 |
| OE24XX | Open Elective I | OE | 3 | 0 | 0 | 3 |
| **Total** | | | | | | **25** |

## CS2401 — Design and Analysis of Algorithms
Unit I: Asymptotic notation, recurrence relations, master theorem.
Unit II: Divide and conquer, greedy method, matroid theory.
Unit III: Dynamic programming, optimal substructure, memoisation.
Unit IV: Graph algorithms, shortest paths, minimum spanning trees, network flow.
Unit V: NP-completeness, reductions, approximation algorithms.

## CS2402 — Operating Systems
Unit I: Process concept, scheduling, context switching.
Unit II: Synchronisation, semaphores, monitors, deadlock.
Unit III: Memory management, paging, segmentation, virtual memory.
Unit IV: File systems, directory structure, allocation methods.
Unit V: I/O systems, disk scheduling, protection and security.

## CS2403 — Computer Networks
Unit I: Layered architectures, OSI and TCP/IP models.
Unit II: Data link layer, error detection, MAC protocols.
Unit III: Network layer, IPv4, IPv6, routing algorithms.
Unit IV: Transport layer, TCP, UDP, congestion control.
Unit V: Application layer, DNS, HTTP, SMTP.

## CS2404 — Database Management Systems
Unit I: Relational model, relational algebra, SQL.
Unit II: Normalisation, functional dependencies, BCNF.
Unit III: Storage, indexing, B+ trees, hashing.
Unit IV: Transactions, ACID, concurrency control, recovery.
Unit V: Distributed databases, NoSQL, introduction to data warehousing.
