# Source

Synthetic. 300 fictional reviews for a fictional product, written for SkillCred assignment 14.
No real review text from any platform is reproduced. Free to redistribute.
