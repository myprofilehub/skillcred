# PRODUCT REVIEWS — Aureus Q2 Wireless Earbuds

300 verified-purchase reviews.

## Review 001
Rating: 5/5
Value for money is hard to beat.

## Review 002
Rating: 5/5
Comfortable to wear for long periods.

## Review 003
Rating: 5/5
Comfortable to wear for long periods.

## Review 004
Rating: 5/5
No lag while watching video.

## Review 005
Rating: 5/5
Build feels far more premium than it costs.

## Review 006
Rating: 5/5
Mic clarity on calls is good.

## Review 007
Rating: 5/5
Fit is secure even while running.

## Review 008
Rating: 5/5
Comfortable to wear for long periods.

## Review 009
Rating: 5/5
Touch controls are responsive.

## Review 010
Rating: 5/5
Touch controls are responsive.

## Review 011
Rating: 3/5
Bass is overpowering and muddy.

## Review 012
Rating: 1/5
Case hinge feels flimsy.

## Review 013
Rating: 5/5
Bass is punchy without being muddy.

## Review 014
Rating: 2/5
Have to charge the battery twice a day with moderate use.

## Review 015
Rating: 3/5
Bass is overpowering and muddy.

## Review 016
Rating: 1/5
Left earbud stopped working after two months.

## Review 017
Rating: 5/5
Build feels far more premium than it costs.

## Review 018
Rating: 2/5
Charging port is loose.

## Review 019
Rating: 5/5
Value for money is hard to beat.

## Review 020
Rating: 5/5
Comfortable to wear for long periods.

## Review 021
Rating: 5/5
Mic clarity on calls is good.

## Review 022
Rating: 4/5
Pairing was instant and has never dropped.

## Review 023
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 024
Rating: 5/5
Setup took under a minute.

## Review 025
Rating: 3/5
Case hinge feels flimsy.

## Review 026
Rating: 5/5
Sound quality is excellent for the price.

## Review 027
Rating: 4/5
Bass is punchy without being muddy.

## Review 028
Rating: 2/5
App is buggy on Android.

## Review 029
Rating: 2/5
Battery lasts under four hours with ANC on.

## Review 030
Rating: 5/5
Pairing was instant and has never dropped.

## Review 031
Rating: 4/5
Ambient mode is useful on the road.

## Review 032
Rating: 2/5
App is buggy on Android.

## Review 033
Rating: 5/5
Touch controls are responsive.

## Review 034
Rating: 5/5
Looks smart and feels sturdy.

## Review 035
Rating: 4/5
Touch controls are responsive.

## Review 036
Rating: 5/5
Build feels far more premium than it costs.

## Review 037
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 038
Rating: 5/5
Sound quality is excellent for the price.

## Review 039
Rating: 2/5
Battery performance in cold weather is terrible.

## Review 040
Rating: 5/5
Comfortable to wear for long periods.

## Review 041
Rating: 3/5
App is buggy on Android.

## Review 042
Rating: 5/5
Comfortable to wear for long periods.

## Review 043
Rating: 5/5
Sound quality is excellent for the price.

## Review 044
Rating: 5/5
Comfortable to wear for long periods.

## Review 045
Rating: 3/5
Charging port is loose.

## Review 046
Rating: 4/5
Touch controls are responsive.

## Review 047
Rating: 3/5
Case hinge feels flimsy.

## Review 048
Rating: 5/5
Sound quality is excellent for the price.

## Review 049
Rating: 5/5
Bass is punchy without being muddy.

## Review 050
Rating: 3/5
Fit is uncomfortable after an hour.

## Review 051
Rating: 3/5
Bass is overpowering and muddy.

## Review 052
Rating: 5/5
Touch controls are responsive.

## Review 053
Rating: 2/5
Connection drops near microwaves.

## Review 054
Rating: 5/5
The case is compact and pocketable.

## Review 055
Rating: 2/5
Fit is uncomfortable after an hour.

## Review 056
Rating: 4/5
Comfortable to wear for long periods.

## Review 057
Rating: 5/5
Bass is punchy without being muddy.

## Review 058
Rating: 4/5
Noise cancellation genuinely surprised me.

## Review 059
Rating: 4/5
Bass is punchy without being muddy.

## Review 060
Rating: 2/5
Battery degraded noticeably after the first month.

## Review 061
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 062
Rating: 5/5
Bass is punchy without being muddy.

## Review 063
Rating: 5/5
No lag while watching video.

## Review 064
Rating: 2/5
Left earbud stopped working after two months.

## Review 065
Rating: 1/5
Battery backup is the single worst thing about these.

## Review 066
Rating: 5/5
Touch controls are responsive.

## Review 067
Rating: 5/5
Sound quality is excellent for the price.

## Review 068
Rating: 5/5
Sound quality is excellent for the price.

## Review 069
Rating: 5/5
Fit is secure even while running.

## Review 070
Rating: 5/5
Fit is secure even while running.

## Review 071
Rating: 5/5
Ambient mode is useful on the road.

## Review 072
Rating: 4/5
Mic clarity on calls is good.

## Review 073
Rating: 5/5
Sound quality is excellent for the price.

## Review 074
Rating: 1/5
Bass is overpowering and muddy.

## Review 075
Rating: 4/5
The case is compact and pocketable.

## Review 076
Rating: 5/5
Fit is secure even while running.

## Review 077
Rating: 5/5
Battery life exceeded what I expected, around seven hours.

## Review 078
Rating: 5/5
Build feels far more premium than it costs.

## Review 079
Rating: 2/5
Touch controls are far too sensitive.

## Review 080
Rating: 3/5
Call quality is poor in wind.

## Review 081
Rating: 5/5
Looks smart and feels sturdy.

## Review 082
Rating: 5/5
Bass is punchy without being muddy.

## Review 083
Rating: 3/5
Touch controls are far too sensitive.

## Review 084
Rating: 3/5
Left earbud stopped working after two months.

## Review 085
Rating: 1/5
Left earbud stopped working after two months.

## Review 086
Rating: 5/5
Pairing was instant and has never dropped.

## Review 087
Rating: 5/5
Bass is punchy without being muddy.

## Review 088
Rating: 4/5
No lag while watching video.

## Review 089
Rating: 4/5
Touch controls are responsive.

## Review 090
Rating: 5/5
Ambient mode is useful on the road.

## Review 091
Rating: 5/5
Comfortable to wear for long periods.

## Review 092
Rating: 2/5
Left earbud stopped working after two months.

## Review 093
Rating: 2/5
Left earbud stopped working after two months.

## Review 094
Rating: 5/5
Touch controls are responsive.

## Review 095
Rating: 1/5
Connection drops near microwaves.

## Review 096
Rating: 4/5
Mic clarity on calls is good.

## Review 097
Rating: 5/5
Ambient mode is useful on the road.

## Review 098
Rating: 2/5
Call quality is poor in wind.

## Review 099
Rating: 5/5
No lag while watching video.

## Review 100
Rating: 5/5
Looks smart and feels sturdy.

## Review 101
Rating: 5/5
No lag while watching video.

## Review 102
Rating: 4/5
Bass is punchy without being muddy.

## Review 103
Rating: 5/5
The case is compact and pocketable.

## Review 104
Rating: 5/5
Setup took under a minute.

## Review 105
Rating: 1/5
Left earbud stopped working after two months.

## Review 106
Rating: 5/5
Mic clarity on calls is good.

## Review 107
Rating: 2/5
The battery takes over two hours to fully charge.

## Review 108
Rating: 2/5
App is buggy on Android.

## Review 109
Rating: 5/5
Looks smart and feels sturdy.

## Review 110
Rating: 3/5
Charging port is loose.

## Review 111
Rating: 1/5
Bass is overpowering and muddy.

## Review 112
Rating: 4/5
Fit is secure even while running.

## Review 113
Rating: 1/5
Bass is overpowering and muddy.

## Review 114
Rating: 2/5
Bass is overpowering and muddy.

## Review 115
Rating: 5/5
Pairing was instant and has never dropped.

## Review 116
Rating: 5/5
Setup took under a minute.

## Review 117
Rating: 5/5
Bass is punchy without being muddy.

## Review 118
Rating: 1/5
Call quality is poor in wind.

## Review 119
Rating: 4/5
Mic clarity on calls is good.

## Review 120
Rating: 2/5
Left earbud stopped working after two months.

## Review 121
Rating: 3/5
Fit is uncomfortable after an hour.

## Review 122
Rating: 2/5
Barely three hours of playback before the battery dies.

## Review 123
Rating: 3/5
Noise cancellation is barely noticeable.

## Review 124
Rating: 3/5
Case hinge feels flimsy.

## Review 125
Rating: 1/5
Battery health dropped fast, now unusable on long flights.

## Review 126
Rating: 5/5
Setup took under a minute.

## Review 127
Rating: 5/5
No lag while watching video.

## Review 128
Rating: 5/5
Ambient mode is useful on the road.

## Review 129
Rating: 4/5
Value for money is hard to beat.

## Review 130
Rating: 5/5
Build feels far more premium than it costs.

## Review 131
Rating: 5/5
Touch controls are responsive.

## Review 132
Rating: 5/5
Pairing was instant and has never dropped.

## Review 133
Rating: 1/5
Call quality is poor in wind.

## Review 134
Rating: 3/5
App is buggy on Android.

## Review 135
Rating: 5/5
Sound quality is excellent for the price.

## Review 136
Rating: 1/5
Fit is uncomfortable after an hour.

## Review 137
Rating: 5/5
No lag while watching video.

## Review 138
Rating: 3/5
Call quality is poor in wind.

## Review 139
Rating: 5/5
Ambient mode is useful on the road.

## Review 140
Rating: 5/5
Bass is punchy without being muddy.

## Review 141
Rating: 5/5
Mic clarity on calls is good.

## Review 142
Rating: 2/5
Left earbud stopped working after two months.

## Review 143
Rating: 2/5
Noise cancellation is barely noticeable.

## Review 144
Rating: 5/5
No lag while watching video.

## Review 145
Rating: 5/5
Value for money is hard to beat.

## Review 146
Rating: 5/5
Build feels far more premium than it costs.

## Review 147
Rating: 5/5
Looks smart and feels sturdy.

## Review 148
Rating: 2/5
Touch controls are far too sensitive.

## Review 149
Rating: 4/5
Ambient mode is useful on the road.

## Review 150
Rating: 3/5
Touch controls are far too sensitive.

## Review 151
Rating: 4/5
Fit is secure even while running.

## Review 152
Rating: 5/5
Pairing was instant and has never dropped.

## Review 153
Rating: 5/5
Touch controls are responsive.

## Review 154
Rating: 5/5
Pairing was instant and has never dropped.

## Review 155
Rating: 4/5
Noise cancellation genuinely surprised me.

## Review 156
Rating: 4/5
The case is compact and pocketable.

## Review 157
Rating: 5/5
Mic clarity on calls is good.

## Review 158
Rating: 5/5
Mic clarity on calls is good.

## Review 159
Rating: 5/5
Mic clarity on calls is good.

## Review 160
Rating: 2/5
Connection drops near microwaves.

## Review 161
Rating: 5/5
Fit is secure even while running.

## Review 162
Rating: 5/5
No lag while watching video.

## Review 163
Rating: 2/5
Touch controls are far too sensitive.

## Review 164
Rating: 5/5
Bass is punchy without being muddy.

## Review 165
Rating: 5/5
Comfortable to wear for long periods.

## Review 166
Rating: 5/5
Setup took under a minute.

## Review 167
Rating: 4/5
No lag while watching video.

## Review 168
Rating: 5/5
Pairing was instant and has never dropped.

## Review 169
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 170
Rating: 5/5
Ambient mode is useful on the road.

## Review 171
Rating: 5/5
Pairing was instant and has never dropped.

## Review 172
Rating: 5/5
Fit is secure even while running.

## Review 173
Rating: 4/5
Comfortable to wear for long periods.

## Review 174
Rating: 2/5
Left earbud stopped working after two months.

## Review 175
Rating: 3/5
Call quality is poor in wind.

## Review 176
Rating: 3/5
Call quality is poor in wind.

## Review 177
Rating: 3/5
Case hinge feels flimsy.

## Review 178
Rating: 4/5
Value for money is hard to beat.

## Review 179
Rating: 5/5
Touch controls are responsive.

## Review 180
Rating: 1/5
Charging port is loose.

## Review 181
Rating: 5/5
Mic clarity on calls is good.

## Review 182
Rating: 5/5
Pairing was instant and has never dropped.

## Review 183
Rating: 5/5
Looks smart and feels sturdy.

## Review 184
Rating: 5/5
Quick charge gives an hour of playback in ten minutes.

## Review 185
Rating: 5/5
Comfortable to wear for long periods.

## Review 186
Rating: 3/5
App is buggy on Android.

## Review 187
Rating: 4/5
Build feels far more premium than it costs.

## Review 188
Rating: 5/5
Comfortable to wear for long periods.

## Review 189
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 190
Rating: 1/5
Advertised battery figures are nowhere close to real usage.

## Review 191
Rating: 4/5
The case is compact and pocketable.

## Review 192
Rating: 2/5
Fit is uncomfortable after an hour.

## Review 193
Rating: 5/5
Touch controls are responsive.

## Review 194
Rating: 1/5
Left earbud stopped working after two months.

## Review 195
Rating: 1/5
Call quality is poor in wind.

## Review 196
Rating: 5/5
Sound quality is excellent for the price.

## Review 197
Rating: 5/5
Fit is secure even while running.

## Review 198
Rating: 1/5
Fit is uncomfortable after an hour.

## Review 199
Rating: 5/5
Mic clarity on calls is good.

## Review 200
Rating: 4/5
Fit is secure even while running.

## Review 201
Rating: 5/5
Looks smart and feels sturdy.

## Review 202
Rating: 5/5
Build feels far more premium than it costs.

## Review 203
Rating: 5/5
Looks smart and feels sturdy.

## Review 204
Rating: 5/5
The case is compact and pocketable.

## Review 205
Rating: 5/5
Ambient mode is useful on the road.

## Review 206
Rating: 4/5
Looks smart and feels sturdy.

## Review 207
Rating: 5/5
Comfortable to wear for long periods.

## Review 208
Rating: 5/5
Ambient mode is useful on the road.

## Review 209
Rating: 5/5
Mic clarity on calls is good.

## Review 210
Rating: 4/5
Mic clarity on calls is good.

## Review 211
Rating: 5/5
Touch controls are responsive.

## Review 212
Rating: 3/5
Fit is uncomfortable after an hour.

## Review 213
Rating: 2/5
Left earbud stopped working after two months.

## Review 214
Rating: 5/5
Build feels far more premium than it costs.

## Review 215
Rating: 2/5
Noise cancellation is barely noticeable.

## Review 216
Rating: 4/5
Bass is punchy without being muddy.

## Review 217
Rating: 5/5
Sound quality is excellent for the price.

## Review 218
Rating: 5/5
Ambient mode is useful on the road.

## Review 219
Rating: 4/5
The case is compact and pocketable.

## Review 220
Rating: 5/5
Comfortable to wear for long periods.

## Review 221
Rating: 3/5
App is buggy on Android.

## Review 222
Rating: 3/5
Case hinge feels flimsy.

## Review 223
Rating: 5/5
Looks smart and feels sturdy.

## Review 224
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 225
Rating: 5/5
Fit is secure even while running.

## Review 226
Rating: 2/5
Battery indicator is wildly inaccurate, jumps from 40% to empty.

## Review 227
Rating: 4/5
Mic clarity on calls is good.

## Review 228
Rating: 2/5
Battery life has halved within four months of use.

## Review 229
Rating: 1/5
Call quality is poor in wind.

## Review 230
Rating: 5/5
Comfortable to wear for long periods.

## Review 231
Rating: 2/5
Left earbud stopped working after two months.

## Review 232
Rating: 2/5
Case hinge feels flimsy.

## Review 233
Rating: 5/5
Ambient mode is useful on the road.

## Review 234
Rating: 3/5
Bass is overpowering and muddy.

## Review 235
Rating: 5/5
The case is compact and pocketable.

## Review 236
Rating: 1/5
Call quality is poor in wind.

## Review 237
Rating: 3/5
Bass is overpowering and muddy.

## Review 238
Rating: 5/5
Build feels far more premium than it costs.

## Review 239
Rating: 5/5
Ambient mode is useful on the road.

## Review 240
Rating: 4/5
Mic clarity on calls is good.

## Review 241
Rating: 1/5
Connection drops near microwaves.

## Review 242
Rating: 5/5
Fit is secure even while running.

## Review 243
Rating: 4/5
Bass is punchy without being muddy.

## Review 244
Rating: 5/5
Build feels far more premium than it costs.

## Review 245
Rating: 5/5
Touch controls are responsive.

## Review 246
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 247
Rating: 3/5
Connection drops near microwaves.

## Review 248
Rating: 2/5
App is buggy on Android.

## Review 249
Rating: 1/5
Battery drains far faster than the advertised eight hours.

## Review 250
Rating: 4/5
Looks smart and feels sturdy.

## Review 251
Rating: 5/5
Ambient mode is useful on the road.

## Review 252
Rating: 5/5
Battery has held up well after six months.

## Review 253
Rating: 4/5
Comfortable to wear for long periods.

## Review 254
Rating: 1/5
App is buggy on Android.

## Review 255
Rating: 1/5
The case battery discharges even when unused.

## Review 256
Rating: 1/5
Touch controls are far too sensitive.

## Review 257
Rating: 3/5
Charging port is loose.

## Review 258
Rating: 5/5
Pairing was instant and has never dropped.

## Review 259
Rating: 3/5
Bass is overpowering and muddy.

## Review 260
Rating: 4/5
Value for money is hard to beat.

## Review 261
Rating: 5/5
The case is compact and pocketable.

## Review 262
Rating: 5/5
Ambient mode is useful on the road.

## Review 263
Rating: 5/5
Bass is punchy without being muddy.

## Review 264
Rating: 2/5
Touch controls are far too sensitive.

## Review 265
Rating: 3/5
Case hinge feels flimsy.

## Review 266
Rating: 4/5
Value for money is hard to beat.

## Review 267
Rating: 2/5
Battery drain overnight is severe, loses 30% sitting idle.

## Review 268
Rating: 1/5
Fit is uncomfortable after an hour.

## Review 269
Rating: 5/5
Battery easily gets me through a full working day.

## Review 270
Rating: 5/5
Comfortable to wear for long periods.

## Review 271
Rating: 5/5
Build feels far more premium than it costs.

## Review 272
Rating: 5/5
Bass is punchy without being muddy.

## Review 273
Rating: 3/5
Connection drops near microwaves.

## Review 274
Rating: 5/5
Value for money is hard to beat.

## Review 275
Rating: 5/5
Value for money is hard to beat.

## Review 276
Rating: 5/5
Pairing was instant and has never dropped.

## Review 277
Rating: 5/5
Setup took under a minute.

## Review 278
Rating: 4/5
Sound quality is excellent for the price.

## Review 279
Rating: 2/5
Noise cancellation is barely noticeable.

## Review 280
Rating: 5/5
Fit is secure even while running.

## Review 281
Rating: 5/5
Comfortable to wear for long periods.

## Review 282
Rating: 5/5
Build feels far more premium than it costs.

## Review 283
Rating: 5/5
Mic clarity on calls is good.

## Review 284
Rating: 3/5
Bass is overpowering and muddy.

## Review 285
Rating: 5/5
Mic clarity on calls is good.

## Review 286
Rating: 5/5
Ambient mode is useful on the road.

## Review 287
Rating: 5/5
Looks smart and feels sturdy.

## Review 288
Rating: 4/5
No lag while watching video.

## Review 289
Rating: 5/5
Pairing was instant and has never dropped.

## Review 290
Rating: 5/5
Setup took under a minute.

## Review 291
Rating: 5/5
Ambient mode is useful on the road.

## Review 292
Rating: 1/5
Fit is uncomfortable after an hour.

## Review 293
Rating: 1/5
Touch controls are far too sensitive.

## Review 294
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 295
Rating: 5/5
Noise cancellation genuinely surprised me.

## Review 296
Rating: 2/5
Right bud battery drains faster than the left.

## Review 297
Rating: 5/5
The case is compact and pocketable.

## Review 298
Rating: 1/5
Fit is uncomfortable after an hour.

## Review 299
Rating: 5/5
Setup took under a minute.

## Review 300
Rating: 4/5
Setup took under a minute.
