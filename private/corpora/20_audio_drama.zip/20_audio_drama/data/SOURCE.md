# Source

Synthetic. 'The Third Drawer' — an original three-episode audio drama written for
SkillCred assignment 20. No film, television or published screenplay is reproduced.
Free to redistribute.
