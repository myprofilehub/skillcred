# RUNBOOK — New Engineer Environment Onboarding
Owner: Developer Experience | Last reviewed: 2026-05-20

## Preconditions
- Laptop issued and enrolled in MDM
- SSO account created and MFA enrolled
- GitHub organisation invitation accepted

## Procedure

1. Install the base toolchain. Run `./bootstrap/install.sh` from the platform-tools repository.
   This installs Docker, kubectl, helm, the AWS CLI and the internal CLI.

2. Authenticate to AWS. Run `aws sso login --profile dev` and confirm you can list S3 buckets.

3. Request cluster access. File a ticket with the Platform team specifying `dev` and `staging`.
   Production access is not granted during the first 30 days.

4. Clone the monorepo and run `make setup`. Expect this to take 20–30 minutes on first run.

5. Start the local stack with `docker compose up`. Confirm all 11 services report healthy.

6. Seed the local database. Run `./scripts/migrate.sh --env local --apply` followed by
   `./scripts/seed.sh`. This is safe to re-run and will reset local data each time.

7. Run the test suite with `make test`. A clean checkout should pass all tests.

8. Open the internal docs site and complete the architecture walkthrough.

9. Pair with your onboarding buddy on a starter ticket labelled `good-first-issue`.

10. Ship one change to staging by the end of week one. This is a deliberate target — the goal is to
    exercise the full path, not to deliver value.

## Common problems
`make setup` fails on Apple Silicon: set `DOCKER_DEFAULT_PLATFORM=linux/amd64` and retry.
Docker compose port conflicts: stop any local Postgres or Redis running outside the stack.
SSO token expiry: tokens last 8 hours; re-run `aws sso login`.
