# RUNBOOK — Production Incident Response
Owner: SRE | Last reviewed: 2026-07-02 | Severity: Sev1–Sev3

## Severity definitions
Sev1: Complete outage or data loss risk. Sev2: Major degradation, workaround exists.
Sev3: Minor degradation, limited blast radius.

## Procedure

1. Acknowledge the page within 5 minutes. If you cannot, let it escalate — do not silence it.

2. Open an incident channel named `#inc-YYYYMMDD-short-description` and post the initial assessment.

3. Assign roles explicitly: Incident Commander, Communications Lead, Operations Lead.
   One person may hold two roles on a Sev3 but never on a Sev1.

4. Post a customer-facing status page update within 15 minutes for Sev1, 30 minutes for Sev2.

5. Establish the timeline. When did it start, what changed, what is the blast radius.
   Check the deployment log first — most incidents follow a change.

6. Stabilise before diagnosing. If a rollback will restore service, roll back and investigate afterwards.

7. **Run the migration rollback** only if the incident was caused by a schema change and the
   Incident Commander has explicitly authorised it. Execute `./scripts/migrate.sh --env prod --down`.
   This drops columns added by the failed migration and **destroys any data written to them**.
   Confirm with the Data team that no production writes have landed in the new columns.

8. Verify service restoration. Confirm error rate has returned to baseline and the status page
   shows all systems operational.

9. Post an update to the status page confirming resolution.

10. Stand down the incident channel but do not archive it. Archive after the postmortem.

11. Schedule the postmortem within 48 hours for Sev1, 5 working days for Sev2.

12. Write the postmortem using the blameless template. Focus on contributing factors, not individuals.

## Escalation path
On-call engineer → On-call lead (15 min) → Engineering Manager (30 min) → CTO (Sev1 only, 60 min)
