# RUNBOOK — API Service Deployment (Production)
Owner: Platform Team | Last reviewed: 2026-06-14 | Severity: Standard change

## Preconditions
- Change ticket approved and in state "Scheduled"
- Deployment window confirmed (Tue/Thu 02:00–04:00 IST only)
- Rollback image tag identified and recorded in the ticket

## Procedure

1. Announce the start of deployment in #deploys with the ticket number and expected duration.

2. Confirm the target cluster context. Run `kubectl config current-context` and verify it reads
   `prod-ap-south-1`. Deploying to the wrong context is the most common incident cause in this runbook.

3. Scale the canary deployment to 1 replica and wait for the pod to reach Ready state.

4. Verify canary health at `/healthz` and confirm the build SHA in the response matches the intended release.

5. Take a database snapshot. Run the snapshot job and wait for completion before proceeding.
   Do not proceed until the snapshot ID is recorded in the ticket.

6. Put the API into maintenance mode. This returns 503 to all write endpoints while leaving reads available.

7. **Run the migration.** Execute `./scripts/migrate.sh --env prod --apply`.
   This step applies schema changes and is **not reversible by re-running the script**.
   Rolling back a migration requires restoring from the snapshot taken in step 5.

8. Verify the migration completed. Check the migration table for the expected version number and
   confirm zero rows in the failed_migrations table.

9. Roll the main deployment to the new image tag. Use `kubectl set image` and watch the rollout status.

10. Wait for all replicas to reach Ready. Do not disable maintenance mode before this completes.

11. Disable maintenance mode.

12. Run the smoke test suite against production. All 34 tests must pass.

13. Monitor error rate and p99 latency for 15 minutes. Error rate above 0.5% triggers rollback.

14. Announce completion in #deploys and move the ticket to "Complete".

## Rollback
If steps 1–6 fail: disable maintenance mode, no further action needed.
If step 7 has completed and rollback is required: this is an incident. Page the on-call lead.
Restore from the snapshot recorded in step 5. Expect 20–40 minutes of downtime.
If steps 9–13 fail and the migration is backward-compatible: roll the image back to the previous tag.
