# CHAPTER 11 — THE HUMAN EYE AND THE COLOURFUL WORLD

## 11.1 The Human Eye
The human eye is one of the most valuable sense organs. It works like a camera, forming a real,
inverted image on a light-sensitive screen.

**Structure:**
- The **cornea** is the transparent front surface. Most of the refraction of incoming light occurs here.
- The **iris** is the coloured muscular diaphragm that controls the size of the pupil.
- The **pupil** is the aperture through which light enters.
- The **eye lens** is a convex lens of a jelly-like material. It provides the fine focusing.
- The **retina** is the light-sensitive screen containing rods and cones.
- The **optic nerve** carries signals to the brain.

## 11.2 Power of Accommodation
The eye lens is held by ciliary muscles. When the muscles relax, the lens becomes thin, its focal
length increases, and distant objects are focused. When the muscles contract, the lens becomes
thicker, its focal length decreases, and nearby objects are focused.

This ability to adjust focal length is called **accommodation**.

The focal length cannot be decreased beyond a limit. The minimum distance at which the eye can see
objects clearly without strain is the **near point**, about 25 cm for a normal young adult.
The farthest point is the **far point**, at infinity for a normal eye.

## 11.3 Defects of Vision and Correction

**Myopia (near-sightedness):** distant objects appear blurred. The image forms in front of the
retina. Caused by excessive curvature of the eye lens or elongation of the eyeball.
Corrected using a **concave lens** of suitable power.

**Hypermetropia (far-sightedness):** nearby objects appear blurred. The image forms behind the
retina. Caused by a focal length that is too long or an eyeball that is too short.
Corrected using a **convex lens** of suitable power.

**Presbyopia:** the power of accommodation decreases with age as ciliary muscles weaken and the
lens becomes rigid. Often requires bifocal lenses — concave in the upper portion for distant
vision, convex in the lower portion for reading.

The power of the corrective lens required is calculated using the lens formula and the definition
of power introduced in Chapter 10. A student who has not understood the sign convention from that
chapter will not be able to work these problems correctly.

## 11.4 Refraction Through a Prism
A prism has two triangular bases and three rectangular lateral surfaces. Light entering a prism
bends towards the base. The angle between the incident ray and the emergent ray is the **angle of
deviation**.

## 11.5 Dispersion of White Light
When white light passes through a prism it splits into its constituent colours — violet, indigo,
blue, green, yellow, orange, red. This is **dispersion**.

Dispersion occurs because different colours bend by different amounts. Violet bends most because it
has the shortest wavelength and the highest refractive index in glass; red bends least.

Newton showed that a second, inverted prism recombines the spectrum back into white light,
demonstrating that the colours come from the light itself and not from the glass.

## 11.6 The Rainbow
A rainbow is a natural spectrum produced by dispersion of sunlight by water droplets. Each droplet
refracts the light on entry, reflects it internally at the back surface, and refracts it again on
exit. The observer must have the Sun behind them.

## 11.7 Atmospheric Refraction
The twinkling of stars, the apparent flattening of the Sun at sunrise and sunset, and the fact that
the Sun is visible about two minutes before actual sunrise are all effects of atmospheric refraction.
Planets do not twinkle because they are extended sources, and the variations across the disc average out.

## 11.8 Scattering of Light
The **Tyndall effect** is the scattering of light by colloidal particles, making the path of a beam
visible.

The sky is blue because air molecules scatter shorter wavelengths more effectively than longer ones.
At sunrise and sunset light travels a longer path through the atmosphere, most of the blue is
scattered away, and the Sun appears red.

## Exercises
1. Why does the eye lens need to change its focal length?
2. Which lens corrects myopia, and why?
3. Explain why the sky appears blue but appears reddish at sunset.
