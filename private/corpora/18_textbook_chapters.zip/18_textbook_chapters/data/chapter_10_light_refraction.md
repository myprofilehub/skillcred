# CHAPTER 10 — LIGHT: REFRACTION

## 10.1 Introduction
When light travels from one transparent medium into another, it changes direction at the boundary.
This bending is called refraction. It happens because the speed of light differs from one medium
to another.

A pencil placed in a glass of water appears bent at the water surface. A coin at the bottom of a
bucket appears raised. Both are consequences of refraction.

## 10.2 The Laws of Refraction
1. The incident ray, the refracted ray, and the normal at the point of incidence all lie in the
   same plane.
2. The ratio of the sine of the angle of incidence to the sine of the angle of refraction is a
   constant for a given pair of media. This is **Snell's law**.

sin i / sin r = n₂₁

where n₂₁ is the refractive index of medium 2 with respect to medium 1.

## 10.3 Refractive Index
The absolute refractive index of a medium is the ratio of the speed of light in vacuum to the speed
of light in that medium:

**n = c / v**

| Medium | Refractive index |
|---|---|
| Vacuum | 1.0000 |
| Air | 1.0003 |
| Water | 1.33 |
| Kerosene | 1.44 |
| Crown glass | 1.52 |
| Diamond | 2.42 |

A medium with a higher refractive index is said to be optically denser. Light bends towards the
normal when entering a denser medium and away from the normal when entering a rarer medium.

## 10.4 Refraction Through a Glass Slab
When light passes through a rectangular glass slab, it refracts twice — once entering and once
leaving. The emergent ray is parallel to the incident ray but laterally displaced. The extent of
displacement depends on the thickness of the slab, the refractive index, and the angle of incidence.

## 10.5 Spherical Lenses
A lens is a transparent medium bounded by two surfaces, at least one of which is curved.
A **convex lens** is thicker at the centre and converges light. A **concave lens** is thinner at
the centre and diverges light.

The optical centre, principal axis, principal focus and focal length are defined analogously to
those of spherical mirrors, discussed in Chapter 9.

## 10.6 Image Formation by a Convex Lens
| Object position | Image position | Size | Nature |
|---|---|---|---|
| At infinity | At F₂ | Highly diminished | Real, inverted |
| Beyond 2F₁ | Between F₂ and 2F₂ | Diminished | Real, inverted |
| At 2F₁ | At 2F₂ | Same size | Real, inverted |
| Between F₁ and 2F₁ | Beyond 2F₂ | Enlarged | Real, inverted |
| At F₁ | At infinity | Highly enlarged | Real, inverted |
| Between F₁ and optical centre | Same side as object | Enlarged | Virtual, erect |

A concave lens always forms a virtual, erect, diminished image regardless of object position.

## 10.7 The Lens Formula and Power
**1/v − 1/u = 1/f**

Magnification m = v/u.

The **power** of a lens is the reciprocal of its focal length in metres:
P = 1/f, measured in dioptres (D). A convex lens has positive power; a concave lens has negative power.

When lenses are placed in contact, their powers add: P = P₁ + P₂ + P₃ ...

## Exercises
1. State Snell's law.
2. The refractive index of diamond is 2.42. What does this mean?
3. A convex lens has focal length 25 cm. Find its power.
