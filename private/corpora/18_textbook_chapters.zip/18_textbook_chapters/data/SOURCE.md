# Source

Synthetic. Three original science chapters written for SkillCred assignment 18 in the style of a
standard secondary-school physics text. No NCERT or other publisher's text is reproduced.
Free to redistribute.
