# CHAPTER 9 — LIGHT: REFLECTION

## 9.1 Introduction
Light is a form of energy that enables us to see. An object becomes visible either because it emits
light of its own, in which case it is called a luminous object, or because it reflects light falling
on it from another source, in which case it is called a non-luminous object. The Sun is luminous;
the Moon is not.

Light travels in straight lines. This property is called rectilinear propagation and explains why
shadows form with sharp edges when the source is small.

## 9.2 Reflection of Light
When light falls on a polished surface it bounces back into the same medium. This is reflection.

**The laws of reflection state:**
1. The angle of incidence is equal to the angle of reflection.
2. The incident ray, the reflected ray, and the normal at the point of incidence all lie in the
   same plane.

These laws hold for all reflecting surfaces, whether plane or curved.

## 9.3 Image Formation by a Plane Mirror
An image formed by a plane mirror is:
- virtual and erect
- the same size as the object
- located as far behind the mirror as the object is in front
- laterally inverted

Lateral inversion is the reason the word AMBULANCE is painted reversed on the front of the vehicle,
so that a driver looking in a rear-view mirror reads it correctly.

## 9.4 Spherical Mirrors
A spherical mirror is a portion of a hollow sphere whose one surface is silvered.
A **concave mirror** has its reflecting surface curved inward. A **convex mirror** has its
reflecting surface curved outward.

Key terms: the pole is the centre of the reflecting surface; the centre of curvature is the centre
of the sphere of which the mirror is a part; the radius of curvature is the distance between them;
the principal focus is the point where rays parallel to the principal axis converge after reflection
from a concave mirror, or appear to diverge from after reflection from a convex mirror.

The focal length is half the radius of curvature: f = R/2.

## 9.5 Image Formation by Concave Mirrors
| Object position | Image position | Size | Nature |
|---|---|---|---|
| At infinity | At F | Highly diminished | Real, inverted |
| Beyond C | Between F and C | Diminished | Real, inverted |
| At C | At C | Same size | Real, inverted |
| Between C and F | Beyond C | Enlarged | Real, inverted |
| At F | At infinity | Highly enlarged | Real, inverted |
| Between P and F | Behind the mirror | Enlarged | Virtual, erect |

## 9.6 Uses
Concave mirrors are used in torches and headlights to produce parallel beams, by dentists to see
enlarged images of teeth, and in solar concentrators.
Convex mirrors are used as rear-view mirrors because they give an erect, diminished image and a
wide field of view.

## 9.7 The Mirror Formula
The mirror formula relates object distance u, image distance v and focal length f:

**1/v + 1/u = 1/f**

Magnification m = height of image / height of object = −v/u.

Sign convention: distances are measured from the pole; distances measured in the direction of
incident light are positive; heights above the principal axis are positive.

## Exercises
1. State the two laws of reflection.
2. Why is a convex mirror preferred as a rear-view mirror?
3. An object is placed 10 cm from a concave mirror of focal length 15 cm. Find the image position.
