# Source

Synthetic. A fictional ~70-minute lecture transcript written for SkillCred assignment 12.
No real lecture, course or captioning output is reproduced. Free to redistribute.
