# Source

Synthetic. Four fictional restaurants, 40 dishes, written for SkillCred assignment 05.
No real restaurant, menu or recipe is reproduced. Free to redistribute.
