# MENUS — four restaurants

Each dish lists its full ingredient declaration as printed on the menu card.

## Anjappar Junction

### Chettinad Chicken Curry
Type: non-veg | Price: INR 280 | Restaurant: Anjappar Junction
Ingredients: chicken, shallots, tomato, coconut, star anise, curry leaves, chilli, black pepper

### Kara Kuzhambu
Type: veg | Price: INR 180 | Restaurant: Anjappar Junction
Ingredients: brinjal, drumstick, tamarind, sambar powder, gingelly oil, curry leaves

### Mutton Chukka
Type: non-veg | Price: INR 340 | Restaurant: Anjappar Junction
Ingredients: mutton, fennel, dry chilli, shallots, coconut slivers, curry leaves

### Vazhaipoo Vadai
Type: veg | Price: INR 120 | Restaurant: Anjappar Junction
Ingredients: banana flower, chana dal, fennel, green chilli, curry leaves

### Chicken 65
Type: non-veg | Price: INR 260 | Restaurant: Anjappar Junction
Ingredients: chicken, curd, ginger garlic paste, red chilli, rice flour, curry leaves

### Paruppu Urundai Kuzhambu
Type: veg | Price: INR 200 | Restaurant: Anjappar Junction
Ingredients: toor dal, tamarind, coconut, shallots, sambar powder

### Nethili Fry
Type: non-veg | Price: INR 240 | Restaurant: Anjappar Junction
Ingredients: anchovy, turmeric, chilli powder, rice flour, curry leaves

### Ennai Kathirikai
Type: veg | Price: INR 190 | Restaurant: Anjappar Junction
Ingredients: brinjal, peanut-sesame masala, tamarind, jaggery, curry leaves

### Kothu Parotta
Type: non-veg | Price: INR 220 | Restaurant: Anjappar Junction
Ingredients: parotta, egg, chicken salna, onion, green chilli, coriander

### Rasam
Type: veg | Price: INR 90 | Restaurant: Anjappar Junction
Ingredients: tomato, tamarind, rasam powder, garlic, coriander, ghee

## Green Fork Cafe

### Buddha Bowl
Type: veg | Price: INR 320 | Restaurant: Green Fork Cafe
Ingredients: quinoa, chickpea, roasted pumpkin, kale, house satay dressing, pomegranate

### Grilled Paneer Skewers
Type: veg | Price: INR 290 | Restaurant: Green Fork Cafe
Ingredients: paneer, capsicum, onion, yoghurt marinade, mint chutney

### Falafel Wrap
Type: veg | Price: INR 270 | Restaurant: Green Fork Cafe
Ingredients: chickpea falafel, tahini sauce, lettuce, tomato, pickled onion, wheat wrap

### Thai Green Curry
Type: veg | Price: INR 340 | Restaurant: Green Fork Cafe
Ingredients: green curry paste, coconut milk, tofu, bamboo shoot, thai basil, jasmine rice

### Beetroot Hummus Platter
Type: veg | Price: INR 250 | Restaurant: Green Fork Cafe
Ingredients: chickpea, beetroot, tahini, olive oil, cucumber, pita

### Zucchini Fritters
Type: veg | Price: INR 230 | Restaurant: Green Fork Cafe
Ingredients: zucchini, gram flour, dill, feta, lemon aioli

### Mushroom Stroganoff
Type: veg | Price: INR 330 | Restaurant: Green Fork Cafe
Ingredients: button mushroom, cream, paprika, onion, egg noodles

### Rainbow Salad
Type: veg | Price: INR 240 | Restaurant: Green Fork Cafe
Ingredients: mixed greens, carrot, red cabbage, orange segments, house satay dressing, sunflower seeds

### Sweet Potato Soup
Type: veg | Price: INR 180 | Restaurant: Green Fork Cafe
Ingredients: sweet potato, coconut milk, ginger, vegetable stock, coriander

### Dark Chocolate Mousse
Type: veg | Price: INR 190 | Restaurant: Green Fork Cafe
Ingredients: dark chocolate, cream, egg, vanilla, sea salt

## Nasi Lemak House

### Nasi Lemak Ayam
Type: non-veg | Price: INR 310 | Restaurant: Nasi Lemak House
Ingredients: coconut rice, fried chicken, sambal, cucumber, anchovy, boiled egg

### Beef Rendang
Type: non-veg | Price: INR 380 | Restaurant: Nasi Lemak House
Ingredients: beef, coconut milk, lemongrass, galangal, kerisik, chilli paste

### Mee Goreng
Type: non-veg | Price: INR 260 | Restaurant: Nasi Lemak House
Ingredients: egg noodle, prawn, beansprout, egg, soy, chilli paste

### Gado Gado
Type: veg | Price: INR 250 | Restaurant: Nasi Lemak House
Ingredients: blanched vegetables, boiled egg, tofu, tempeh, peanut sauce, prawn crackers

### Roti Canai with Dhal
Type: veg | Price: INR 140 | Restaurant: Nasi Lemak House
Ingredients: flour, ghee, dhal curry, onion, cumin

### Char Kway Teow
Type: non-veg | Price: INR 290 | Restaurant: Nasi Lemak House
Ingredients: flat rice noodle, prawn, chinese sausage, egg, beansprout, dark soy

### Sayur Lodeh
Type: veg | Price: INR 220 | Restaurant: Nasi Lemak House
Ingredients: cabbage, long bean, carrot, coconut milk, turmeric, tempeh

### Satay Ayam (6 sticks)
Type: non-veg | Price: INR 300 | Restaurant: Nasi Lemak House
Ingredients: chicken, turmeric marinade, peanut sauce, cucumber, ketupat

### Sambal Terung
Type: veg | Price: INR 210 | Restaurant: Nasi Lemak House
Ingredients: brinjal, sambal, shallot, tamarind

### Cendol
Type: veg | Price: INR 150 | Restaurant: Nasi Lemak House
Ingredients: pandan jelly, coconut milk, palm sugar, shaved ice

## The Deccan Grill

### Hyderabadi Chicken Biryani
Type: non-veg | Price: INR 360 | Restaurant: The Deccan Grill
Ingredients: basmati, chicken, saffron, fried onion, mint, yoghurt, whole spices

### Veg Dum Biryani
Type: veg | Price: INR 290 | Restaurant: The Deccan Grill
Ingredients: basmati, mixed vegetables, saffron, fried onion, mint, yoghurt

### Mirchi Ka Salan
Type: veg | Price: INR 180 | Restaurant: The Deccan Grill
Ingredients: green chilli, peanut-sesame gravy, tamarind, coconut

### Haleem
Type: non-veg | Price: INR 320 | Restaurant: The Deccan Grill
Ingredients: mutton, wheat, lentils, ghee, fried onion, ginger

### Double Ka Meetha
Type: veg | Price: INR 160 | Restaurant: The Deccan Grill
Ingredients: bread, milk, sugar, cardamom, cashew, raisin, ghee

### Tandoori Pomfret
Type: non-veg | Price: INR 420 | Restaurant: The Deccan Grill
Ingredients: pomfret, yoghurt, carom, chilli, lemon

### Dal Bukhara
Type: veg | Price: INR 240 | Restaurant: The Deccan Grill
Ingredients: black urad dal, tomato, cream, butter, ginger

### Kebab Platter
Type: non-veg | Price: INR 390 | Restaurant: The Deccan Grill
Ingredients: chicken seekh, mutton shami, paneer tikka, mint chutney

### Bagara Baingan
Type: veg | Price: INR 220 | Restaurant: The Deccan Grill
Ingredients: brinjal, peanut-sesame gravy, tamarind, curry leaves

### Qubani Ka Meetha
Type: veg | Price: INR 170 | Restaurant: The Deccan Grill
Ingredients: dried apricot, sugar, cream
