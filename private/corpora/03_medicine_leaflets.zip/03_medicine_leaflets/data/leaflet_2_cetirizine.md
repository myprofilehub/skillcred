# PATIENT INFORMATION LEAFLET — ZYRTEC-C 10 (Cetirizine Hydrochloride 10 mg Tablets)

## What Zyrtec-C is and what it is used for
Zyrtec-C contains cetirizine, an antihistamine. It relieves the symptoms of allergic rhinitis
(sneezing, runny nose, itchy eyes) and chronic urticaria (hives).

## Before you take Zyrtec-C
Do not take if you are allergic to cetirizine, hydroxyzine, or piperazine derivatives.
Do not take if you have severe kidney disease.
Tell your doctor if you have moderate kidney impairment, epilepsy, or difficulty passing urine.

## Warnings and precautions
Cetirizine may cause drowsiness. Do not drive or operate machinery until you know how this
medicine affects you.

Alcohol may increase drowsiness. Avoid alcohol while taking this medicine.

If you are due to have allergy skin testing, stop taking this medicine three days before the test,
as it will interfere with the result.

## Taking Zyrtec-C with other medicines
Cetirizine does not have significant interactions with most common medicines. However, tell your
doctor if you are taking theophylline, ritonavir, or any sedative medicine.
Taking cetirizine together with paracetamol is not known to cause any interaction. Both may be
taken as directed on their respective labels.

## How to take Zyrtec-C
Adults and children over 12 years: one tablet (10 mg) once daily.
Children 6 to 12 years: half a tablet (5 mg) twice daily.
Children 2 to 6 years: 2.5 mg twice daily, using the oral solution rather than tablets.
Patients with moderate kidney impairment: one tablet every other day.
Take at the same time each day. May be taken with or without food.

## Possible side effects
Common: drowsiness, dry mouth, headache, fatigue.
Uncommon: abdominal pain, diarrhoea, agitation.
Rare: rapid heartbeat, liver function abnormalities, weight gain.
Very rare: severe allergic reaction with swelling of the face or throat — seek emergency care.

## Storage
Store below 25°C. Keep out of the sight and reach of children.
