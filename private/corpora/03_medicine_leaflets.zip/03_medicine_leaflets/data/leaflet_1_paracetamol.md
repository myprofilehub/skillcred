# PATIENT INFORMATION LEAFLET — PARACIN 500 (Paracetamol 500 mg Tablets)

## What Paracin is and what it is used for
Paracin contains paracetamol. It is used for the relief of mild to moderate pain including headache,
toothache, muscular aches, period pain and backache. It is also used to reduce fever.

## Before you take Paracin
Do not take Paracin if you are allergic to paracetamol or any other ingredient in this product.
Tell your doctor before taking Paracin if you have liver or kidney problems, if you drink alcohol
regularly, if you are underweight or malnourished, or if you are taking any other medicine
containing paracetamol.

## Warnings and precautions
Do not exceed the stated dose. Overdose of paracetamol causes severe and sometimes irreversible
liver damage. Symptoms of overdose may not appear for several days. If an overdose is suspected,
seek immediate medical attention even if the person feels well.

Many combination cold and flu preparations contain paracetamol. Taking Paracin alongside such a
preparation can result in accidental overdose. Always check the label of every product being taken.

Prolonged use without medical supervision is not advised. If pain persists beyond three days or
fever beyond three days, consult a doctor.

## Taking Paracin with other medicines
Tell your doctor if you are taking warfarin or other anticoagulants, as regular use of paracetamol
may increase the risk of bleeding. Occasional use is not a concern.
Tell your doctor if you are taking metoclopramide, domperidone, colestyramine, or medicines for
epilepsy or tuberculosis.

## How to take Paracin
Adults and children over 16 years: one to two tablets every four to six hours as required.
Do not take more than eight tablets in twenty-four hours. Do not take doses less than four hours apart.
Swallow whole with water. May be taken with or without food.

## Possible side effects
Uncommon: rash, itching, swelling. Rare: blood disorders, liver dysfunction.
Stop taking Paracin and seek medical advice immediately if you develop a skin rash or peeling skin.

## Storage
Store below 30°C in a dry place. Keep out of the sight and reach of children.
