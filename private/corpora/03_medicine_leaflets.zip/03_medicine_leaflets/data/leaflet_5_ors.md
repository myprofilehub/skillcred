# PATIENT INFORMATION LEAFLET — REHYDRAL ORS (Oral Rehydration Salts, Sachet)

## What Rehydral is and what it is used for
Rehydral is an oral rehydration salt preparation containing sodium chloride, potassium chloride,
sodium citrate and anhydrous glucose. It is used to replace fluid and electrolytes lost through
diarrhoea, vomiting or excessive sweating.

## Before you use Rehydral
Do not use if you have intestinal obstruction, severe kidney impairment, or are unable to drink.
Tell your doctor if you have diabetes, kidney disease, or are on a low-sodium diet.

## Warnings and precautions
Rehydral is not a treatment for the cause of diarrhoea. It replaces lost fluid only.
Seek medical advice if diarrhoea continues beyond 24 hours in a young child, 48 hours in an older
child, or 72 hours in an adult.

Seek urgent care if there are signs of severe dehydration: sunken eyes, no urine for eight hours,
unusual drowsiness, cold hands and feet, or rapid breathing.

Prepare with drinking water only. Do not prepare with milk, juice or soft drinks.
Do not add sugar or salt to the prepared solution.

## Using Rehydral with other medicines
No significant interactions are known. Rehydral may be given alongside paracetamol or other
medicines as directed.

## How to prepare and use Rehydral
Dissolve the entire contents of one sachet in 1 litre of clean drinking water. Do not use part of a sachet.
Use the prepared solution within 24 hours. Discard any solution left after 24 hours.
Adults and adolescents: 200 to 400 ml after each loose motion.
Children: as advised by a doctor, based on the child's weight and degree of dehydration.
Infants: continue breastfeeding alongside; a doctor must advise the volume.

## Possible side effects
Uncommon: nausea, vomiting if drunk too quickly. Sip slowly.
Rare: high sodium levels if prepared in too little water, causing puffiness and irritability.

## Storage
Store below 30°C. Use the sachet immediately after opening. Keep out of the sight and reach of children.
