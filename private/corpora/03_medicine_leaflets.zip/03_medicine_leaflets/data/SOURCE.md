# Source

Synthetic. Five fictional patient information leaflets written for SkillCred assignment 03.
Brand names are invented. No manufacturer's leaflet is reproduced.

WARNING: This corpus is a teaching artefact. The clinical content is plausible but has NOT been
verified by a pharmacist and must never be used for any actual medical decision. Free to redistribute.
