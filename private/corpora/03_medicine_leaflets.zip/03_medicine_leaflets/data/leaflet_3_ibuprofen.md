# PATIENT INFORMATION LEAFLET — BRUFAST 400 (Ibuprofen 400 mg Tablets)

## What Brufast is and what it is used for
Brufast contains ibuprofen, a non-steroidal anti-inflammatory drug (NSAID). It is used for pain,
inflammation and fever, including headache, dental pain, period pain, muscular and joint pain,
and symptoms of colds and flu.

## Before you take Brufast
Do not take Brufast if you have or have had a stomach ulcer, bleeding in the stomach or intestine,
severe heart failure, severe liver or kidney disease, or if you are in the last three months of pregnancy.
Do not take if aspirin or another NSAID has caused asthma, wheezing, rash or nasal swelling.

## Warnings and precautions
NSAIDs may increase the risk of heart attack and stroke, particularly at high doses and with
prolonged use. Use the lowest effective dose for the shortest time.

Taking ibuprofen may cause bleeding in the stomach. The risk is higher in the elderly, at higher
doses, with prolonged use, and when taken with alcohol or corticosteroids.

Take with or after food to reduce stomach irritation.

Do not take with other NSAIDs including aspirin at anti-inflammatory doses, diclofenac or naproxen.

## Taking Brufast with other medicines
Tell your doctor if you take: warfarin or other anticoagulants; aspirin; corticosteroids; SSRIs;
diuretics; ACE inhibitors; lithium; methotrexate; ciclosporin.

Ibuprofen and paracetamol act by different mechanisms and are sometimes taken together or
alternately under medical advice. Both are available in many combination products, so check the
label of every product being taken to avoid exceeding the maximum dose of either.

## How to take Brufast
Adults and children over 12 years: one tablet (400 mg) up to three times daily with food.
Do not exceed 1200 mg in twenty-four hours without medical advice.
Leave at least six hours between doses.
Children under 12 years should not take the 400 mg tablet. Paediatric ibuprofen suspension is
available. **Children aged 6 months to 12 years: 5 to 10 mg per kilogram of body weight per dose,
up to three doses in twenty-four hours, using the suspension.** Doses for children must be
determined by a doctor or pharmacist against the child's current weight.

## Possible side effects
Common: indigestion, nausea, abdominal pain.
Uncommon: headache, dizziness, rash.
Serious — stop and seek urgent medical care: vomiting blood, black tarry stools, severe abdominal
pain, swelling of the face, difficulty breathing, chest pain.

## Storage
Store below 30°C. Keep out of the sight and reach of children.
