# PATIENT INFORMATION LEAFLET — OMEZOL 20 (Omeprazole 20 mg Gastro-Resistant Capsules)

## What Omezol is and what it is used for
Omezol contains omeprazole, a proton pump inhibitor. It reduces the amount of acid produced by the
stomach. It is used for heartburn and acid reflux, stomach ulcers, and to protect the stomach in
people taking long-term NSAIDs.

## Before you take Omezol
Do not take if you are allergic to omeprazole or other proton pump inhibitors.
Do not take with nelfinavir.
Tell your doctor if you have liver disease, or if you have unexplained weight loss, difficulty
swallowing, vomiting blood, or black stools — these need investigation before treatment.

## Warnings and precautions
Long-term use (over one year) may increase the risk of bone fracture and of low magnesium levels.
Discuss with your doctor if you have been taking this medicine continuously for more than a year.

Omeprazole may mask the symptoms of stomach cancer. If symptoms persist despite treatment,
further investigation is required.

Taking omeprazole may increase the risk of certain gut infections.

## Taking Omezol with other medicines
Tell your doctor if you take: clopidogrel; warfarin; phenytoin; diazepam; digoxin; methotrexate;
ketoconazole or itraconazole; rifampicin; St John's wort.
Omeprazole does not interact with paracetamol.

## How to take Omezol
Adults: one capsule (20 mg) once daily, in the morning, before food.
Swallow whole with water. Do not chew or crush the capsule.
For heartburn: usually 14 days of treatment. Do not continue beyond four weeks without medical advice.
For ulcer treatment: as directed by your doctor, usually four to eight weeks.

## Possible side effects
Common: headache, abdominal pain, constipation, diarrhoea, wind, nausea.
Uncommon: sleep disturbance, dizziness, rash, raised liver enzymes.
Rare: low sodium, confusion, blood disorders.
Very rare: severe skin reactions — stop and seek urgent medical care.

## Storage
Store below 25°C in the original container. Keep out of the sight and reach of children.
