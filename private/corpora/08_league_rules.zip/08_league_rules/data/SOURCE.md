# Source

Synthetic. The SkillCred Premier League is a fictional competition. These conditions and laws were
written for SkillCred assignment 08 and are an original composition.
No text from the MCC Laws of Cricket, the ICC playing conditions, or any real league's rulebook is
reproduced. Free to redistribute.
