# SKILLCRED PREMIER LEAGUE — GENERAL LAWS (EXTRACT)
These are the baseline laws adopted by the SPL. Where the Playing Conditions provide otherwise,
the Playing Conditions prevail.

## GL30 — THE STRIKER OUT OF THEIR GROUND
A striker is out of their ground unless some part of the bat or person is grounded behind the
popping crease.

## GL32 — CAUGHT
GL32.1 The striker is out Caught if a ball delivered by the bowler, not being a no ball, touches
the bat and is subsequently held by a fielder as a fair catch before it touches the ground.

GL32.2 A catch is fair if the ball, having been struck by the bat, makes contact with the person or
protective equipment of a fielder, or with the helmet worn by the striker, and is thereafter held
before touching the ground.

GL32.3 The ball is not held as a fair catch if a fielder touches the boundary while in contact with the ball.

## GL33 — LBW
The striker is out LBW if the ball would have gone on to hit the wicket, pitched in line or outside
off stump, and struck the striker in line, provided no shot was offered or the ball struck the
striker in line having pitched in line.

## GL38 — RUN OUT
Either batter is out Run out if, at any time while the ball is in play, they are out of their
ground and their wicket is fairly put down by the opposing side.

## GL41 — UNFAIR PLAY
GL41.1 The captains are responsible for ensuring play is conducted within the spirit of the game.
GL41.2 Deliberate short runs, deliberate distraction, and time wasting are unfair play.

## GL42 — PENALTY RUNS
Where penalty runs are awarded they are added to the score of the side to which they are awarded
and, where the batting side receives them, are not credited to any individual batter.
