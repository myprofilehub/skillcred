# SKILLCRED PREMIER LEAGUE — PLAYING CONDITIONS 2026
Issued by the SPL Technical Committee. These conditions govern all SPL fixtures.
Where these conditions are silent, the General Laws of the game as adopted by the SPL apply.

## PC1 — MATCH FORMAT
PC1.1 Each innings is limited to 20 overs.
PC1.2 The PP shall be the first 6 overs of each innings.
PC1.3 During the PP a maximum of 2 fielders are permitted outside the 30-yard circle.
PC1.4 Outside the PP a maximum of 5 fielders are permitted outside the 30-yard circle.
PC1.5 No bowler shall bowl more than 4 overs in an innings.

## PC2 — THE TOSS AND TEAM SHEETS
PC2.1 The toss shall take place 30 minutes before the scheduled start.
PC2.2 Team sheets naming 11 players and up to 4 substitutes, including the ISUB, shall be exchanged at the toss.
PC2.3 The ISUB may be introduced at any point after the completion of the 14th over of the first innings.
PC2.4 An ISUB who replaces a player may bat and bowl in full, subject to PC1.5.
PC2.5 A player replaced by the ISUB takes no further part in the match.

## PC3 — SO AND TIE RESOLUTION
PC3.1 Where the scores are level at the conclusion of both innings, a SO shall be played.
PC3.2 The SO consists of one over per side, bowled by a bowler nominated at the time.
PC3.3 Each side nominates 3 batters. The innings ends on the loss of 2 wickets.
PC3.4 Where the SO is also tied, a second SO is played. This repeats until a result is obtained.
PC3.5 In the group stage only, where the SO cannot be completed due to weather, the point is shared.

## PC4 — DRS
PC4.1 Each side is permitted 2 unsuccessful reviews per innings.
PC4.2 A review must be requested within 15 seconds of the umpire's decision.
PC4.3 The UO is the sole determinant where ball-tracking is inconclusive.
PC4.4 A review resulting in umpire's call does not count against a side's allocation.
PC4.5 DRS is not available in group-stage fixtures at venues without ball-tracking installed.

## PC5 — NO BALL AND FREE HIT
PC5.1 A front-foot no ball results in a FH for the following delivery.
PC5.2 A FH also results from a no ball for exceeding the permitted fielders outside the circle.
PC5.3 On a FH the striker cannot be dismissed other than by run out, hit the ball twice, or obstructing the field.
PC5.4 The field may not be changed for a FH unless the striker has changed ends.
PC5.5 A waist-high full toss above waist height to a standing batter is a no ball and results in a FH.

## PC6 — DISMISSALS AND PROTECTIVE EQUIPMENT
PC6.1 The methods of dismissal are as set out in the General Laws.
PC6.2 LBW decisions are subject to DRS in accordance with PC4.
PC6.3 A batter who is struck on the helmet shall undergo a mandatory concussion assessment.

PC6.4 **Notwithstanding anything contained in the General Laws, where the ball, after being struck
by the bat, makes contact with the helmet worn by the striker, or with any protective equipment
worn by a fielder, and is thereafter caught before touching the ground, the striker shall be
adjudged NOT OUT and the ball shall be called dead. This condition applies to all SPL fixtures and
departs deliberately from the General Laws, under which such a catch is fair.**

PC6.5 Where the ball makes contact with a helmet worn by a fielder and is not caught, runs
completed shall stand and 5 penalty runs shall be awarded to the batting side.

PC6.6 A concussion substitute is permitted and is a like-for-like replacement approved by the
Match Referee. A concussion substitute is distinct from the ISUB and does not consume that allocation.

## PC7 — MANKAD AND NON-STRIKER RUN OUT
PC7.1 The bowler may run out the non-striker before the instant at which the bowler would normally
have been expected to release the ball. This is a legitimate mode of dismissal and shall not be
regarded as against the spirit of the game.
PC7.2 No warning is required.

## PC8 — OVER RATE
PC8.1 Each innings shall be completed within 85 minutes.
PC8.2 Where the fielding side falls behind, an additional fielder must be brought inside the
circle for all remaining overs.
PC8.3 Repeated over-rate offences attract a fine on the captain as per the Code of Conduct.

## PC9 — WEATHER AND REDUCED OVERS
PC9.1 A minimum of 5 overs per side constitutes a match.
PC9.2 Where overs are reduced, the PP is recalculated as 30% of the revised innings, rounded up.
PC9.3 The DLS method applies to all interrupted matches.
PC9.4 Bowler allocations are recalculated as one fifth of the revised innings, rounded up.

## PC10 — POINTS
PC10.1 Win: 2 points. Tie resolved by SO: 2 points to the winner. No result: 1 point each.
PC10.2 NRR is the first tiebreaker, followed by head-to-head, followed by the toss of a coin.
