# Source

Synthetic. Three fictional banks, written for SkillCred assignment 10.
No real bank's product literature, FAQ page or rate card is reproduced. All rates, charges and
conditions are invented and must not be relied upon. Free to redistribute.
