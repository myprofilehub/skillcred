# KAVERI BANK — HOUSING FINANCE: COMMON QUESTIONS

## Getting Started

**Am I eligible?**
Kaveri Bank offers housing finance to salaried and self-employed resident Indians between 23 and 58
years of age at the time of application. The loan must conclude before the applicant turns 65.

**What income do I need to show?**
The minimum gross monthly income is INR 28,000 for salaried applicants anywhere in India.
Kaveri Bank does not distinguish between metro and non-metro income requirements.
Self-employed applicants must show a minimum annual turnover of INR 15,00,000.

**How many months of salary slips do you need?**
Kaveri Bank requires salary slips for the last six months, not three. This is stricter than the
market norm and is applied without exception, including to applicants of long standing with the bank.
Along with the slips we require Form 16 for two years and six months of bank statements.

## Rates and Costs

**What interest rate applies?**
Kaveri Bank housing finance is offered at a rate linked to the repo benchmark. The current
effective range is 8.55% to 10.10% per annum depending on credit profile and loan-to-value ratio.

**Is the interest rate fixed or floating?**
Both are offered. The fixed option is available for the first three years only, after which the
loan converts to floating automatically.

**What are the charges?**
Processing fee of 0.50% of the sanctioned amount plus taxes, minimum INR 7,500.
Legal and technical valuation charges of INR 4,500 are payable separately and are non-refundable
even if the loan is not sanctioned.
Documentation charges of INR 2,000.

**Can I repay early?**
Floating rate loans carry no foreclosure charge for individual borrowers.
Part prepayment is permitted twice per financial year without charge, with a minimum of one EMI.

## Amount, Tenure, Security

**What is the maximum loan?**
Kaveri Bank funds up to 85% of the agreement value for properties up to INR 50 lakh, and up to 75%
above that. Stamp duty and registration charges are not included in the property value for this
calculation.

**What is the longest tenure available?**
Twenty-five years. Kaveri Bank does not offer thirty-year housing finance.

**What security is required?**
An equitable mortgage of the financed property by deposit of title deeds. No additional collateral
is required for loans up to INR 1 crore.

## Other

**Do you offer a balance transfer?**
Yes. Balance transfer from another lender is processed at nil processing fee where the outstanding
exceeds INR 20 lakh and the applicant has a clean twelve-month repayment record.

**Is there a top-up facility?**
A top-up of up to 20% of the original sanction is available after eighteen months of satisfactory
repayment.
