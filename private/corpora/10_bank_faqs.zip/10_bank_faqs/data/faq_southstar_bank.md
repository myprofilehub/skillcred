# SOUTHSTAR BANK — HOME LOAN HELP CENTRE

## Eligibility Questions

**What are the age limits?**
Applicants must be at least 21 years old at application and not more than 62 years old at loan
maturity. There is no separate limit for self-employed applicants.

**What is the minimum income?**
INR 25,000 net monthly for salaried applicants. For self-employed applicants, INR 3,50,000 net
annual income as per the latest income tax return.

**Does my credit score matter?**
Yes. A CIBIL score of 700 or above is required for standard processing. Applications between 650
and 700 are considered on merit at a higher spread. Below 650, applications are generally declined.

## Documents

**What salary documents are needed?**
Three months of salary slips, the last two Form 16s, and six months of bank statements showing
salary credits. Where variable pay forms more than 25% of income, twelve months of slips are required.

**Do you accept digital documents?**
Yes, all documents may be uploaded through the SouthStar app. Originals are verified at the time of
disbursement only.

## Money Matters

**What is the rate of interest?**
SouthStar home loans start at 8.35% per annum, linked to the repo rate. The spread is determined by
credit score, loan amount, and whether the applicant holds a salary account with SouthStar.
Salary account holders receive a concession of 10 basis points.

**How is interest charged?**
On a daily reducing balance basis, which is marginally more favourable to the borrower than the
monthly reducing basis used by most lenders.

**What is the processing fee?**
A flat INR 10,000 plus taxes regardless of loan amount. There is no percentage-based fee.

**What happens if I miss an EMI?**
A penal charge of 2% per month applies on the overdue amount. Three consecutive missed EMIs
trigger classification as a non-performing asset and recovery proceedings.

## Loan Structure

**What is the maximum I can borrow?**
Up to 90% of property value for loans up to INR 35 lakh, 80% for loans up to INR 75 lakh, and 75%
beyond. The maximum single loan is INR 5 crore.

**What tenures do you offer?**
Up to thirty years, subject to the age limit at maturity.

**Can I get a moratorium?**
A moratorium of up to 24 months is available for under-construction properties. During the
moratorium only interest is payable.

**Do you offer an overdraft-linked home loan?**
Yes, the SouthStar FlexiHome product links the loan to a current account. Surplus funds parked in
the account reduce the interest payable. There is no restriction on withdrawal of the surplus.
