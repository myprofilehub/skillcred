# MERIDIAN BANK — HOME LOAN FREQUENTLY ASKED QUESTIONS

## Eligibility

**Who can apply for a Meridian home loan?**
Salaried individuals aged 21 to 60 and self-employed individuals aged 21 to 65 at loan maturity.
Indian residents and Non-Resident Indians are both eligible.

**What is the minimum income requirement?**
Salaried applicants in metro cities require a net monthly income of INR 30,000. In non-metro
locations the requirement is INR 25,000. Self-employed applicants require an annual profit after
tax of INR 4,00,000 as per the last two filed returns.

**How long must I have been employed?**
A minimum of two years of total work experience, of which at least six months must be with the
current employer.

## Documentation

**What income documents are required for salaried applicants?**
Salary slips for the last three months, Form 16 for the last two financial years, and bank
statements showing salary credit for the last six months.

**What income documents are required for self-employed applicants?**
Income tax returns with computation of income for the last three years, audited financials for the
last two years, and current account statements for the last twelve months.

**What identity and address documents are required?**
PAN card is mandatory. Aadhaar, passport, voter identity card or driving licence is accepted for
address. Utility bills not older than three months are accepted as secondary address proof.

**What property documents are required?**
Sale agreement, approved building plan, chain of title documents, encumbrance certificate for
thirteen years, and the latest property tax receipt.

## Interest and Charges

**What is the rate of interest?**
Meridian home loans are linked to the external benchmark rate. The spread over the benchmark
depends on the applicant's credit score and loan amount. The effective rate currently ranges from
8.40% to 9.75% per annum.

**How is the interest calculated?**
Interest is calculated on a monthly reducing balance basis.

**What is the processing fee?**
0.35% of the loan amount, subject to a minimum of INR 5,000 and a maximum of INR 12,500,
plus applicable taxes.

**Are there prepayment charges?**
For floating rate loans to individual borrowers, there are no prepayment or foreclosure charges.
For fixed rate loans, a charge of 2% of the amount prepaid applies where prepayment is made from
borrowed funds.

## Loan Amount and Tenure

**How much can I borrow?**
Up to 90% of the property value for loans up to INR 30 lakh, up to 80% for loans between INR 30
lakh and INR 75 lakh, and up to 75% for loans above INR 75 lakh.

**What is the maximum tenure?**
Thirty years, or until the applicant reaches 60 years of age (salaried) or 65 years (self-employed),
whichever is earlier.

**What is the EMI to income ratio permitted?**
Total obligations including the proposed EMI should not exceed 55% of net monthly income for
applicants earning above INR 1,00,000 per month, and 45% for applicants below that threshold.

## Process

**How long does approval take?**
In-principle approval within three working days of complete documentation. Final sanction after
legal and technical clearance of the property, typically seven to ten working days.

**Can I apply jointly?**
Yes. Up to three co-applicants are permitted. Co-applicants must be immediate family members.
Income of co-applicants is aggregated for eligibility.
