# ORBIT LABS — PEOPLE HANDBOOK, SECTION 5: LEAVE

## 5.1 Our approach
We do not track leave in fine detail. We expect people to take the time they need and to
communicate clearly with their team. That said, statutory minimums and a few practical limits apply.

## 5.2 Annual leave
Every employee has 24 days of annual leave per financial year (April to March).
There is no distinction between casual and earned leave at Orbit.
Annual leave is credited in full on 1 April.

## 5.3 Carry forward
Up to 10 days of unused annual leave carries forward into the following financial year.
Carried-forward days must be used by 30 September or they lapse.
There is no encashment of annual leave at Orbit under any circumstances, including at exit.

## 5.4 Sick days
Sick days are not counted against annual leave and are not capped. We ask for a doctor's note for
any absence longer than three consecutive working days.
Persistent absence is handled as a wellbeing conversation, not a disciplinary one.

## 5.5 Parental leave
26 weeks for the primary caregiver, 6 weeks for the secondary caregiver, regardless of gender.
Available after six months of service.

## 5.6 Notice and approval
Leave of up to two days: inform your team, no approval needed.
Leave of three to ten days: two weeks' notice, manager approval.
Leave beyond ten days: one month's notice, manager and function head approval.

## 5.7 Team coverage
No more than 30% of any team may be on leave simultaneously. The team lead resolves clashes on a
first-applied basis.

## 5.8 Working hours
We do not have core hours. We have four hours of overlap with your team's timezone, which you and
your team agree between yourselves.

## 5.9 Company shutdown
Orbit closes for one week between Christmas and New Year. This does not count against annual leave.
