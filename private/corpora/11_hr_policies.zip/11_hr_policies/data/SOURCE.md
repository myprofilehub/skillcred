# Source

Synthetic. Three fictional companies, written for SkillCred assignment 11.
No real employer's policy document is reproduced. Free to redistribute.
