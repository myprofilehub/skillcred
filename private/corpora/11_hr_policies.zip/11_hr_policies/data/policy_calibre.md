# CALIBRE ANALYTICS PRIVATE LIMITED — TIME OFF POLICY
Version 4.2, effective 1 January 2025.

## Purpose
This policy sets out the time-off entitlements available to employees of Calibre Analytics and the
process for requesting and approving time off.

## Entitlements

| Leave Type | Days Per Calendar Year | Accrual | Carry Forward |
|---|---|---|---|
| Privilege Leave | 21 | Monthly, 1.75 days | Up to 30 days |
| Casual Leave | 8 | Credited annually on 1 January | Nil |
| Sick Leave | 10 | Credited annually on 1 January | Nil |
| Bereavement Leave | 5 | As required | Not applicable |
| Marriage Leave | 5 | Once during employment | Not applicable |

## Probation
Employees on probation accrue privilege leave but may not avail it until confirmation.
Casual and sick leave are available from the date of joining at a pro-rated rate.

## Application Process
All leave is applied for through the HRMS portal. Retrospective applications are accepted only for
sick leave and bereavement leave.
Privilege leave of five days or more requires 14 days' notice.
Approval rests with the reporting manager. Escalation is to the skip-level manager.

## Blackout Periods
No privilege leave is approved during the two weeks preceding a quarter end, except in emergencies
approved by the function head.

## Encashment
Privilege leave in excess of the carry-forward ceiling is encashed annually at basic salary.
Casual and sick leave are never encashed and lapse at year end for all employees at all grades.

## Public Holidays
Twelve public holidays per calendar year, of which eight are fixed and four are floating.
Floating holidays must be used within the calendar year and do not carry forward.

## Sabbatical
Employees with five or more years of continuous service may apply for an unpaid sabbatical of
between one and six months, subject to business requirements and function head approval.

## Exit
On resignation, privilege leave balance is encashed in the final settlement. Any leave availed in
excess of accrued balance is recovered from the final settlement.
