# NORTHWIND SYSTEMS — LEAVE AND ATTENDANCE POLICY
Effective 1 April 2024. Applies to all confirmed employees in India.

## 1. Leave Year
The leave year runs from 1 April to 31 March. Leave is credited in advance on 1 April and
pro-rated for employees joining mid-year.

## 2. Categories of Leave

### 2.1 Casual Leave (CL)
All confirmed employees are entitled to **12 days of casual leave** per leave year.
Casual leave is intended for short, unplanned absences. It may be taken in half-day units.
A maximum of three consecutive days of casual leave may be taken at one time.
Casual leave may not be combined with earned leave.

### 2.2 Earned Leave (EL)
All confirmed employees are entitled to 18 days of earned leave per leave year, credited at
1.5 days per completed month of service.
Earned leave requires approval at least seven days in advance for absences of three days or more.

### 2.3 Sick Leave (SL)
12 days per leave year. A medical certificate is required for absences exceeding two consecutive days.

### 2.4 Maternity and Paternity Leave
As per the Maternity Benefit Act. Paternity leave is 10 working days within six months of birth.

## 3. Carry-Forward

Unused earned leave may be carried forward to the next leave year up to a maximum of 45 days.
Earned leave beyond 45 days at year end is encashed at basic salary.

Unused casual leave lapses at the end of the leave year and is not encashable.

Notwithstanding the paragraph above, employees at Grade M3 and above may carry forward unused
casual leave to the following leave year, subject to a ceiling of **6 days**. This carry-forward
was introduced in the April 2023 revision in recognition of the travel demands placed on senior
staff and does not extend to Grades M1 and M2.

Unused sick leave lapses at the end of the leave year.

## 4. Grades
Grade M1: Associate and Senior Associate.
Grade M2: Lead and Senior Lead.
Grade M3: Manager and Senior Manager.
Grade M4: Director and above.

## 5. Attendance
Core hours are 11:00 to 16:00. Employees are expected to be available during core hours.
A minimum of nine working hours per day averaged over the month is required.
Three or more instances of unreported absence in a quarter is treated as a disciplinary matter.

## 6. Work From Home
Up to eight days per month with manager approval. Not deducted from any leave balance.
Employees on performance improvement plans are not eligible for work from home.

## 7. Leave Without Pay
Granted only after all applicable leave balances are exhausted, at the discretion of the
department head, up to a maximum of 30 days in a leave year.

## 8. Notice Period Interaction
Leave may not be taken during the notice period except with written approval from Human Resources.
Unused earned leave is encashed in the final settlement. Unused casual leave is not encashed.
