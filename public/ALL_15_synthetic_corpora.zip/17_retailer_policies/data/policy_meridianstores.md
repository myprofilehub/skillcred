# MERIDIAN STORES — RETURNS POLICY

## Return Period
Meridian Stores permits returns within **14 days** of the delivery date.

The 14-day period applies to all categories other than those listed below:
- Apparel and footwear: 30 days
- Electronics and accessories: 14 days
- Home and kitchen: 21 days
- Beauty and personal care: 14 days, unopened only
- Jewellery: 14 days, with the original certificate

## Requirements
The item must be returned in its original condition, with all packaging, tags, labels, accessories,
user manuals and warranty documentation intact.
The invoice or order confirmation must accompany the return.
Any item that has been used, altered, resized or damaged by the customer is not eligible.

## Return Process
Log in and select Return from your order history. Meridian Stores schedules a courier pickup within
72 hours. Self-ship is available where pickup is not serviceable, with shipping reimbursed up to
INR 120 on submission of the courier receipt.

## Refund Method and Timeline
Refunds are processed within 3 to 5 working days after the item is received and inspected.
Refunds are issued to the original payment method. Meridian Stores does not offer store credit
refunds unless requested by the customer.
Cash on delivery orders are refunded by bank transfer within 5 to 8 working days.

## Exchange Policy
Meridian Stores operates a direct size exchange for apparel and footwear within the 30-day window.
For colour or style changes, return the original item and place a new order.

## Warranty
Warranty claims are handled by the manufacturer. Meridian Stores assists by providing purchase
proof and brand service centre details on request.

## Exclusions
Gift cards, downloadable content, customised orders, opened cosmetics, and any item sold under a
"Clearance — No Return" label.
