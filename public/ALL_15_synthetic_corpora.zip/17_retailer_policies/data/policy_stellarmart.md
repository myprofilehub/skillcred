# STELLARMART — RETURN AND REFUND POLICY

## Eligibility for Return
StellarMart offers a **21-day** return window from the date of delivery across most categories.

Category exceptions:
- Books and stationery: 15 days
- Mobile phones and tablets: 7 days
- Furniture: 10 days, assembled items subject to disassembly charge
- Health supplements: not returnable once seal is broken

## Return Conditions
Products must be in original condition with all tags, manuals, warranty cards and accessories.
Serial numbers must match those recorded at dispatch.
Items showing signs of use beyond reasonable inspection are refused.

## Initiating a Return
Returns are raised through My Orders. StellarMart arranges reverse pickup at no cost for all
serviceable pincodes. For non-serviceable pincodes, self-ship with reimbursement up to INR 200.

## Refunds
Refund is initiated after the returned item passes inspection at the warehouse.
Prepaid: 4 to 6 working days to the original payment method.
COD: 6 to 9 working days by NEFT to the account provided.
StellarMart Credit: instant.

## Replacement
Replacement is offered instead of refund where the item is defective and stock is available.
Replacement requests must be raised within the same window as returns.

## Warranty Support
StellarMart provides doorstep warranty support for large appliances for the full manufacturer
warranty period. For all other categories, warranty is serviced by the brand.

## Items Not Eligible
Perishables, personalised goods, innerwear, opened software, e-gift vouchers, and clearance items
explicitly marked non-returnable.
