# URBANLEAF — RETURNS, REFUNDS AND WARRANTY POLICY

## Returns Window
UrbanLeaf accepts returns within **30 days** of delivery for most categories.
The following categories carry a shorter window:
- Innerwear, swimwear and socks: not returnable
- Perishables and groceries: 24 hours, damage or spoilage only
- Consumer electronics: 10 days
- Large appliances: 7 days, subject to technician inspection

## Condition of Returned Goods
Items must be unused, unwashed, and returned with all original tags, packaging, accessories and
freebies. Apparel returned without tags is refused at pickup.
Footwear must be tried on indoors only. Soles showing outdoor wear are refused.

## How to Return
Initiate the return from the Orders page in the app or website. A pickup is scheduled within 48
hours. Where pickup is unavailable at your pincode, a self-ship option is offered and shipping
costs up to INR 150 are reimbursed on receipt.

## Refund Timelines
Prepaid orders: refunded to the original payment method within 5 to 7 working days of quality check.
Cash on delivery orders: refunded to a bank account you provide, within 7 to 10 working days.
UrbanLeaf Wallet refunds are instant on quality check.

## Exchanges
Size exchanges on apparel and footwear are free and unlimited within the 30-day window.
Colour and style exchanges are treated as a return followed by a fresh order.

## Warranty
Manufacturer warranty applies as stated on the product page. UrbanLeaf facilitates warranty claims
for the first 6 months; thereafter customers deal directly with the brand service centre.

## Non-Returnable Items
Customised or personalised products, gift cards, digital downloads, opened cosmetics and
fragrances, and items marked "Final Sale" on the product page.
