# Source

Synthetic. Five fictional retailers, written for SkillCred assignment 17.
No real retailer's policy page is reproduced. All windows, charges and terms are invented.
Free to redistribute.
