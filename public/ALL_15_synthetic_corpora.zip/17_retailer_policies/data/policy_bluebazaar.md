# BLUE BAZAAR — RETURN, REPLACEMENT AND REFUND TERMS

## Window
Blue Bazaar operates a **10-day** return window across the marketplace.
Individual sellers may offer longer windows; where a seller offers longer, the seller's window
prevails and is displayed on the product page.

Category rules:
- Fashion: 10 days, seller-dependent, many sellers offer 30 days
- Electronics: 10 days for replacement only, no refund unless the item is dead on arrival
- Groceries: same day, quality issues only
- Furniture and fittings: 10 days, inspection required

## Marketplace Structure
Blue Bazaar is a marketplace. The contract of sale is between the customer and the seller.
Blue Bazaar facilitates returns but the seller's policy governs, subject to the minimum standards
in this document.

## Condition
Original packaging, tags, accessories and invoice must be returned. Serial-numbered goods are
matched against dispatch records.

## Process
Raise the request in the app. Blue Bazaar coordinates pickup with the seller's logistics partner.
Pickup is typically within 4 working days, longer for seller-fulfilled items.
Self-ship reimbursement is capped at INR 100 and requires seller approval before shipping.

## Refunds
Refunds are released after the seller confirms receipt and condition.
Prepaid: 7 to 10 working days. COD: 8 to 12 working days.
Blue Bazaar Pay balance: 2 working days.

## Replacement
Replacement is the default remedy for electronics. Refund is offered only where replacement stock
is unavailable for 15 days.

## Not Returnable
Innerwear, perishables, personalised items, digital goods, opened beauty products, and anything
listed by the seller as non-returnable at the time of purchase.
