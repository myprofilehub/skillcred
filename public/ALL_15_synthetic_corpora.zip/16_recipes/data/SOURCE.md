# Source

Synthetic. 60 fictional recipe entries written for SkillCred assignment 16.
No copyrighted recipe text is reproduced. Free to redistribute.
