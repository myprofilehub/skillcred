# RECIPE COLLECTION

60 recipes with structured metadata.

## Lemon Rice
Type: veg | Cook time: 15 minutes | Cuisine: south indian
Ingredients: cooked rice, lemon, mustard seed, peanut, turmeric, curry leaves

## Curd Rice
Type: veg | Cook time: 10 minutes | Cuisine: south indian
Ingredients: cooked rice, curd, mustard seed, ginger, green chilli, curry leaves

## Tomato Rasam
Type: veg | Cook time: 20 minutes | Cuisine: south indian
Ingredients: tomato, tamarind, rasam powder, garlic, coriander

## Paneer Butter Masala
Type: veg | Cook time: 35 minutes | Cuisine: north indian
Ingredients: paneer, tomato, cashew, butter, cream, kasuri methi

## Palak Paneer
Type: veg | Cook time: 30 minutes | Cuisine: north indian
Ingredients: spinach, paneer, garlic, cream, cumin

## Paneer Tikka
Type: veg | Cook time: 40 minutes | Cuisine: north indian
Ingredients: paneer, yoghurt, capsicum, onion, tandoori masala

## Kadai Paneer
Type: veg | Cook time: 28 minutes | Cuisine: north indian
Ingredients: paneer, capsicum, tomato, coriander seed, dried chilli

## Matar Paneer
Type: veg | Cook time: 32 minutes | Cuisine: north indian
Ingredients: paneer, green peas, tomato, ginger, garam masala

## Chilli Paneer
Type: veg | Cook time: 26 minutes | Cuisine: indo chinese
Ingredients: paneer, capsicum, soy sauce, vinegar, cornflour, spring onion

## Aloo Jeera
Type: veg | Cook time: 18 minutes | Cuisine: north indian
Ingredients: potato, cumin, turmeric, coriander

## Bhindi Fry
Type: veg | Cook time: 20 minutes | Cuisine: north indian
Ingredients: okra, onion, amchur, chilli powder

## Veg Fried Rice
Type: veg | Cook time: 15 minutes | Cuisine: indo chinese
Ingredients: cooked rice, carrot, beans, spring onion, soy sauce

## Gobi Manchurian
Type: veg | Cook time: 30 minutes | Cuisine: indo chinese
Ingredients: cauliflower, cornflour, ginger, garlic, soy sauce, chilli

## Chana Masala
Type: veg | Cook time: 25 minutes | Cuisine: north indian
Ingredients: chickpea, onion, tomato, chana masala, ginger

## Rajma
Type: veg | Cook time: 45 minutes | Cuisine: north indian
Ingredients: kidney bean, onion, tomato, garam masala

## Dal Tadka
Type: veg | Cook time: 25 minutes | Cuisine: north indian
Ingredients: toor dal, garlic, cumin, ghee, dried chilli

## Sambar
Type: veg | Cook time: 30 minutes | Cuisine: south indian
Ingredients: toor dal, drumstick, tamarind, sambar powder, shallot

## Upma
Type: veg | Cook time: 15 minutes | Cuisine: south indian
Ingredients: semolina, onion, green chilli, mustard seed, curry leaves

## Poha
Type: veg | Cook time: 12 minutes | Cuisine: west indian
Ingredients: flattened rice, onion, potato, peanut, turmeric, lemon

## Besan Chilla
Type: veg | Cook time: 15 minutes | Cuisine: north indian
Ingredients: gram flour, onion, tomato, coriander, ajwain

## Masala Dosa
Type: veg | Cook time: 40 minutes | Cuisine: south indian
Ingredients: dosa batter, potato, onion, mustard seed, turmeric

## Idli with Chutney
Type: veg | Cook time: 20 minutes | Cuisine: south indian
Ingredients: idli batter, coconut, green chilli, ginger, mustard seed

## Vegetable Pulao
Type: veg | Cook time: 25 minutes | Cuisine: north indian
Ingredients: basmati, carrot, beans, peas, whole spices

## Pav Bhaji
Type: veg | Cook time: 30 minutes | Cuisine: west indian
Ingredients: potato, tomato, capsicum, pav bhaji masala, butter, pav

## Aloo Paratha
Type: veg | Cook time: 35 minutes | Cuisine: north indian
Ingredients: wheat flour, potato, coriander, ajwain, ghee

## Tomato Omelette (eggless)
Type: veg | Cook time: 12 minutes | Cuisine: south indian
Ingredients: gram flour, tomato, onion, green chilli, coriander

## Cucumber Salad
Type: veg | Cook time: 8 minutes | Cuisine: salad
Ingredients: cucumber, lemon, chaat masala, coriander

## Sprouts Sundal
Type: veg | Cook time: 18 minutes | Cuisine: south indian
Ingredients: moong sprouts, coconut, mustard seed, curry leaves

## Bread Upma
Type: veg | Cook time: 12 minutes | Cuisine: south indian
Ingredients: bread, onion, tomato, mustard seed, turmeric

## Maggi Masala Bowl
Type: veg | Cook time: 8 minutes | Cuisine: quick
Ingredients: instant noodles, onion, tomato, peas, masala sachet

## Chicken Curry
Type: non-veg | Cook time: 40 minutes | Cuisine: south indian
Ingredients: chicken, onion, tomato, coconut, curry powder

## Chicken 65
Type: non-veg | Cook time: 30 minutes | Cuisine: south indian
Ingredients: chicken, curd, chilli, rice flour, curry leaves

## Egg Bhurji
Type: non-veg | Cook time: 12 minutes | Cuisine: north indian
Ingredients: egg, onion, tomato, green chilli, turmeric

## Egg Fried Rice
Type: non-veg | Cook time: 15 minutes | Cuisine: indo chinese
Ingredients: cooked rice, egg, spring onion, soy sauce

## Fish Fry
Type: non-veg | Cook time: 25 minutes | Cuisine: south indian
Ingredients: fish, turmeric, chilli powder, rice flour, lemon

## Prawn Masala
Type: non-veg | Cook time: 30 minutes | Cuisine: south indian
Ingredients: prawn, onion, tomato, coconut, curry leaves

## Mutton Sukka
Type: non-veg | Cook time: 50 minutes | Cuisine: south indian
Ingredients: mutton, fennel, dried chilli, coconut, shallot

## Chicken Biryani
Type: non-veg | Cook time: 55 minutes | Cuisine: north indian
Ingredients: basmati, chicken, yoghurt, fried onion, saffron, mint

## Butter Chicken
Type: non-veg | Cook time: 45 minutes | Cuisine: north indian
Ingredients: chicken, tomato, butter, cream, kasuri methi

## Omelette
Type: non-veg | Cook time: 8 minutes | Cuisine: quick
Ingredients: egg, onion, green chilli, coriander, salt

## Keema Matar
Type: non-veg | Cook time: 35 minutes | Cuisine: north indian
Ingredients: minced mutton, peas, onion, tomato, garam masala

## Chilli Chicken
Type: non-veg | Cook time: 30 minutes | Cuisine: indo chinese
Ingredients: chicken, capsicum, soy sauce, cornflour, chilli

## Fish Curry
Type: non-veg | Cook time: 35 minutes | Cuisine: south indian
Ingredients: fish, tamarind, coconut, shallot, fenugreek

## Egg Curry
Type: non-veg | Cook time: 28 minutes | Cuisine: south indian
Ingredients: boiled egg, onion, tomato, coconut, curry powder

## Chicken Soup
Type: non-veg | Cook time: 25 minutes | Cuisine: soup
Ingredients: chicken, garlic, pepper, coriander, cornflour

## Tomato Soup
Type: veg | Cook time: 20 minutes | Cuisine: soup
Ingredients: tomato, garlic, butter, pepper, cream

## Sweet Corn Soup
Type: veg | Cook time: 18 minutes | Cuisine: soup
Ingredients: sweet corn, cornflour, pepper, spring onion

## Fruit Custard
Type: veg | Cook time: 15 minutes | Cuisine: dessert
Ingredients: milk, custard powder, sugar, mixed fruit

## Semiya Payasam
Type: veg | Cook time: 25 minutes | Cuisine: dessert
Ingredients: vermicelli, milk, sugar, cardamom, cashew, raisin

## Gulab Jamun
Type: veg | Cook time: 40 minutes | Cuisine: dessert
Ingredients: milk powder, flour, ghee, sugar syrup, cardamom

## Kesari
Type: veg | Cook time: 20 minutes | Cuisine: dessert
Ingredients: semolina, ghee, sugar, saffron, cashew

## Ragi Malt
Type: veg | Cook time: 10 minutes | Cuisine: beverage
Ingredients: ragi flour, milk, jaggery, cardamom

## Filter Coffee
Type: veg | Cook time: 10 minutes | Cuisine: beverage
Ingredients: coffee decoction, milk, sugar

## Masala Chai
Type: veg | Cook time: 10 minutes | Cuisine: beverage
Ingredients: tea, milk, ginger, cardamom, sugar

## Buttermilk
Type: veg | Cook time: 5 minutes | Cuisine: beverage
Ingredients: curd, water, ginger, curry leaves, salt

## Veg Sandwich
Type: veg | Cook time: 10 minutes | Cuisine: snack
Ingredients: bread, cucumber, tomato, butter, chaat masala

## Paneer Sandwich
Type: veg | Cook time: 25 minutes | Cuisine: snack
Ingredients: bread, paneer, capsicum, onion, butter, chaat masala

## Corn Chaat
Type: veg | Cook time: 12 minutes | Cuisine: snack
Ingredients: sweet corn, onion, tomato, lemon, chaat masala

## Peanut Sundal
Type: veg | Cook time: 20 minutes | Cuisine: snack
Ingredients: peanut, coconut, mustard seed, curry leaves

## Banana Smoothie
Type: veg | Cook time: 5 minutes | Cuisine: beverage
Ingredients: banana, milk, honey, cardamom
