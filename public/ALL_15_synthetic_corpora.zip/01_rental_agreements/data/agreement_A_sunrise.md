# RENTAL AGREEMENT — SUNRISE RESIDENCY (Property A)

This Agreement is made between Sunrise Residency Property Holdings (hereinafter "the Lessor")
and the occupant (hereinafter "the Lessee") for the premises at Flat 3B, Sunrise Residency.

## Clause 1 — Term
1.1 The term of this Agreement shall be eleven (11) months from the date of commencement.
1.2 The Agreement may be renewed by mutual written consent not less than thirty (30) days prior to expiry.
1.3 Renewal shall be at a rent revised upward by not more than seven percent (7%) of the then-prevailing rent.

## Clause 2 — Rent and Payment
2.1 Monthly rent is INR 18,000 payable on or before the fifth (5th) day of each calendar month.
2.2 Payment shall be made by bank transfer only. Cash payments are not accepted and will not be acknowledged.
2.3 A late payment charge of INR 500 per week applies from the sixth (6th) day of the month.
2.4 Rent for a part month at commencement shall be pro-rated on a daily basis.

## Clause 3 — Security Deposit
3.1 The Lessee shall deposit a sum equal to three (3) months' rent, being INR 54,000, prior to occupation.
3.2 The deposit is interest-free and is held against damage, unpaid rent, and unpaid utilities.
3.3 **In the event the Lessee vacates the premises before the completion of six (6) months from the
date of commencement, the entire security deposit shall stand forfeited to the Lessor, irrespective
of the condition of the premises at the time of vacating.**
3.4 Where the Lessee completes six (6) months or more, the deposit shall be refunded within
forty-five (45) days of vacating, less lawful deductions.
3.5 Deductions under Clause 3.4 shall be itemised in writing. Normal wear and tear shall not be deducted.

## Clause 4 — Notice
4.1 Either party may terminate by giving two (2) months' written notice.
4.2 Notice given by the Lessee does not alter the operation of Clause 3.3.
4.3 The Lessor may terminate with fifteen (15) days' notice in the event of breach of Clause 6.

## Clause 5 — Maintenance and Utilities
5.1 A monthly maintenance charge of INR 2,500 is payable in addition to rent.
5.2 Electricity and water are metered separately and billed directly to the Lessee.
5.3 Minor repairs up to INR 1,000 per instance are the responsibility of the Lessee.
5.4 Structural repairs, plumbing mains, and external painting are the responsibility of the Lessor.

## Clause 6 — Use of Premises
6.1 The premises shall be used for residential purposes only.
6.2 Subletting is prohibited without prior written consent of the Lessor.
6.3 The maximum number of occupants is three (3).
6.4 Pets are not permitted.
6.5 Commercial activity of any nature, including home tuition for payment, is prohibited.

## Clause 7 — Access
7.1 The Lessor may enter the premises for inspection with twenty-four (24) hours' notice.
7.2 In an emergency the Lessor may enter without notice.

## Clause 8 — Dispute Resolution
8.1 This Agreement is governed by the laws of India.
8.2 Disputes shall be referred to a sole arbitrator appointed by mutual consent.
8.3 The seat of arbitration shall be Chennai.
