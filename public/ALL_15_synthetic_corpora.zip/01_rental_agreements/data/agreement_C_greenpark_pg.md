# PAYING GUEST ACCOMMODATION AGREEMENT — GREEN PARK PG (Property C)

Between Green Park Accommodations ("the Management") and the resident ("the Resident").

## Clause 1 — Period of Stay
1.1 The minimum period of stay is three (3) months.
1.2 Thereafter the arrangement continues on a month-to-month basis.
1.3 The Management may revise charges with thirty (30) days' notice.

## Clause 2 — Charges
2.1 Monthly charges: INR 12,000 for a twin-sharing room, INR 16,000 for a single room.
2.2 Charges are inclusive of two meals daily, wifi, and housekeeping twice weekly.
2.3 Charges are payable on or before the first (1st) of each month.
2.4 A late fee of INR 300 per day applies after the fifth (5th).

## Clause 3 — Caution Deposit
3.1 A caution deposit of one (1) month's charges is payable at the time of joining.
3.2 The deposit covers damage to furniture, fittings, linen and keys.
3.3 The deposit is refundable within fifteen (15) days of vacating, subject to Clause 3.4.
3.4 Where the Resident vacates before completing the minimum three (3) month period, the deposit
is refundable in full provided fifteen (15) days' notice was given. Where such notice was not given,
one (1) month's charges shall be deducted in lieu of notice.
3.5 Loss of a room key attracts a deduction of INR 500.

## Clause 4 — Notice
4.1 Fifteen (15) days' written notice is required to vacate.
4.2 Notice may be given at any time including during the minimum stay period.

## Clause 5 — House Rules
5.1 Entry gate closes at 11:00 PM. Late entry requires prior intimation to the warden.
5.2 Visitors are permitted in the common lounge until 8:00 PM only.
5.3 Visitors are not permitted in rooms at any time.
5.4 Cooking in rooms is prohibited.
5.5 Alcohol and smoking are prohibited on the premises.
5.6 Rooms are subject to inspection by the warden at any reasonable hour.

## Clause 6 — Meals
6.1 Breakfast is served 07:30 to 09:30. Dinner is served 19:30 to 21:30.
6.2 Lunch is not included and may be purchased separately.
6.3 No refund or adjustment is made for meals not consumed.

## Clause 7 — Termination by Management
7.1 The Management may terminate immediately for breach of Clause 5.5.
7.2 In such an event the caution deposit stands forfeited.

## Clause 8 — Liability
8.1 The Management is not liable for loss of personal belongings.
8.2 Residents are advised to use the lockers provided.
