# LEAVE AND LICENCE AGREEMENT — LAKEVIEW ENCLAVE (Property B)

Between Lakeview Enclave Owners Association ("the Licensor") and the occupant ("the Licensee")
for Unit 12, Lakeview Enclave.

## Clause 1 — Duration
1.1 This Licence subsists for eleven (11) months from the commencement date.
1.2 Extension requires a fresh instrument; this Licence does not auto-renew.
1.3 Any extension shall be at a rent not exceeding a ten percent (10%) increase.

## Clause 2 — Licence Fee
2.1 The monthly licence fee is INR 22,000, payable in advance by the third (3rd) of each month.
2.2 Payment by bank transfer or UPI is accepted. Cheques are accepted subject to realisation.
2.3 Delay beyond seven (7) days attracts interest at eighteen percent (18%) per annum on the outstanding sum.

## Clause 3 — Interest-Free Refundable Deposit
3.1 The Licensee shall place an interest-free refundable deposit of INR 66,000, equal to three months' fee.
3.2 The deposit secures the Licensor against damage, arrears, and unpaid statutory dues.
3.3 **Where the Licensee vacates prior to the completion of six (6) months, the Licensor shall
deduct from the deposit a sum equal to one month's licence fee for each remaining month of the
minimum six-month period, and shall refund the balance. The deposit shall not be forfeited in full.**
3.4 Where the Licensee completes six (6) months or more, the full deposit less lawful deductions
shall be refunded within thirty (30) days of handover of keys.
3.5 Deductions shall be supported by invoices or photographs. Fair wear and tear is excluded.

## Clause 4 — Termination
4.1 Either party may terminate on one (1) month's written notice.
4.2 The consequences of early vacating are governed exclusively by Clause 3.3.
4.3 Immediate termination is available to the Licensor upon breach of Clause 6.2 or Clause 6.5.

## Clause 5 — Outgoings
5.1 Association maintenance of INR 3,200 per month is included in the licence fee.
5.2 Electricity, water and gas are billed to the Licensee at actuals.
5.3 Repairs below INR 1,500 per instance are borne by the Licensee.
5.4 The Licensor bears the cost of structural and common-area repairs.

## Clause 6 — Conditions of Occupation
6.1 Residential use only.
6.2 No subletting, no paying-guest arrangement, no short-stay letting.
6.3 Maximum four (4) occupants.
6.4 One domestic pet is permitted with written intimation to the Association.
6.5 No activity causing nuisance to neighbouring units.

## Clause 7 — Inspection
7.1 Forty-eight (48) hours' written notice is required for inspection.
7.2 Emergency access is permitted without notice, with intimation as soon as practicable.

## Clause 8 — Governing Law
8.1 Governed by the laws of India, courts at Chennai having exclusive jurisdiction.
